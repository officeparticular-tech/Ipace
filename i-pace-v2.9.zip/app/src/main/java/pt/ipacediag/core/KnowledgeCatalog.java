package pt.ipacediag.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Conhecimento i-Pace (2018-2020) — a base mais completa que consegui compilar e
 * VERIFICAR em múltiplas fontes (fabricante, manual/boletins Jaguar, fóruns
 * i-paceforum/ipaceforums/SpeakEV, Reddit, projetos de GitHub/OVMS, bases de TSB).
 *
 * Cada facto tem o seu estatuto de fonte:
 *   OFICIAL    — plano/manual/boletim Jaguar ou dado do fabricante
 *   COMUNIDADE — consenso ou relato recorrente de donos/fóruns
 *   INCERTO    — sem fonte oficial pública fiável; não confirmado
 *
 * Princípio: rigor acima de tudo. Onde não há dado oficial, diz-se — não se
 * inventam números. Pura Java (testável sem Android).
 */
public final class KnowledgeCatalog {
    private KnowledgeCatalog() {}

    public enum Status { OFICIAL, COMUNIDADE, INCERTO }

    public static final class Item {
        public final Status status;
        public final String title;
        public final String body;
        public final String source;
        public Item(Status status, String title, String body, String source) {
            this.status = status; this.title = title; this.body = body; this.source = source;
        }
    }

    public static final class Section {
        public final String id, title, intro;
        public final List<Item> items;
        Section(String id, String title, String intro, List<Item> items) {
            this.id = id; this.title = title; this.intro = intro; this.items = items;
        }
    }

    private static Item of(Status s, String t, String b, String src) { return new Item(s, t, b, src); }

    private static final List<Section> SECTIONS = new ArrayList<>();

    private static void section(String id, String title, String intro, Item... items) {
        SECTIONS.add(new Section(id, title, intro, new ArrayList<>(Arrays.asList(items))));
    }

    static {
        // ============================= MANUTENÇÃO =============================
        section("manut", "Manutenção (oficial + preventiva)",
                "O plano oficial Jaguar e a manutenção preventiva aconselhada pela comunidade. Onde há discordância, está assinalada.",
                of(Status.OFICIAL, "Revisão periódica",
                        "A cada 2 anos ou ~34.000 km (21.000 milhas), o que ocorrer primeiro. Inclui inspeção multipontos, atualização de "
                        + "software, serviço e lubrificação das pinças de travão, rotação dos pneus, filtro de habitáculo e verificação do nível "
                        + "do líquido de arrefecimento da bateria de alta tensão. Sem mudança de óleo de motor (é elétrico).",
                        "Jaguar «Passport to Service» / concessionários"),
                of(Status.OFICIAL, "Líquido de travões",
                        "Substituir a cada ~3 anos, independentemente da quilometragem.",
                        "Plano de serviço Jaguar / especialistas"),
                of(Status.OFICIAL, "Filtro do habitáculo (pólen)",
                        "Substituir aproximadamente a cada 2 anos (na revisão).",
                        "Plano de serviço Jaguar"),
                of(Status.COMUNIDADE, "Líquido de arrefecimento (bateria HV)",
                        "Intervalo longo; especialistas referem ~5 anos / ~145.000 km (90.000 milhas). Verificar sempre nível e estado — "
                        + "arrefece a bateria de alta tensão e a eletrónica de potência.",
                        "Especialistas de serviço / comunidade"),
                of(Status.COMUNIDADE, "Travões de fricção (atenção nos EV)",
                        "Com a travagem regenerativa, discos e pinças trabalham pouco e tendem a enferrujar e a gripar. Usar os travões com "
                        + "firmeza de vez em quando, inspeção anual e limpeza/lubrificação das pinças.",
                        "Comunidade i-Pace / boa prática EV"),
                of(Status.COMUNIDADE, "Pneus",
                        "Rotação regular (peso + binário gastam depressa e desigual), pressão correta (TPMS) e alinhamento periódico.",
                        "Comunidade i-Pace"),
                of(Status.OFICIAL, "Software / atualizações (OTA)",
                        "Manter atualizado é dos pontos mais importantes: corrige muitos problemas (12V, Pivi/InControl, climatização, BECM). "
                        + "Atualizações over-the-air (SOTA) desde 2020.",
                        "Jaguar / comunidade"),
                of(Status.COMUNIDADE, "Vedantes e drenos",
                        "Manter limpos os drenos (para-brisas, teto e, sobretudo, o dreno do evaporador do A/C) para evitar infiltrações.",
                        "Comunidade i-Pace"),
                of(Status.INCERTO, "Óleo das unidades de tração (EDU) / «caixa de transferência»",
                        "O i-Pace NÃO tem caixa de transferência — é dual-motor, com redução de 1 velocidade por eixo (duas EDU). A Jaguar NÃO "
                        + "lista mudança do óleo das unidades no plano (tratadas como vitalícias/seladas). Parte da comunidade defende mudança "
                        + "preventiva, mas NÃO há intervalo nem capacidade oficiais publicados para o i-Pace — por isso não se indica aqui um "
                        + "número. Se quiser fazê-lo, só com oficina que confirme lubrificante e procedimento.",
                        "Layout: Wikipedia · debate: fóruns Jaguar"));

        // ============================== FLUIDOS ==============================
        section("fluidos", "Fluidos & capacidades",
                "O que a marca recomenda e as quantidades, quando são públicas. Confirme na especificação Jaguar do seu carro.",
                of(Status.OFICIAL, "Líquido de travões",
                        "DOT 4 de baixa humidade (ISO 4925). Substituição ~3 anos.",
                        "Especificação Jaguar"),
                of(Status.INCERTO, "Líquido de arrefecimento",
                        "Tipo OAT (ácido orgânico) aprovado pela Jaguar, pré-misturado 50/50 (laranja). Vários circuitos (bateria HV + "
                        + "eletrónica/motores). Capacidade total NÃO publicada — confirmar na oficina. Não usar anticongelante genérico.",
                        "Especificação Jaguar (tipo) · capacidade não publicada"),
                of(Status.OFICIAL, "Ar condicionado (gás + óleo)",
                        "Gás R-1234yf, ~850 g. ATENÇÃO: compressor ELÉTRICO → óleo NÃO condutor (tipo POE, ou PAO aprovado, p. ex. PAO 68), "
                        + "~150 ml. NÃO usar óleo PAG comum (é condutor e compromete o isolamento de alta tensão). Confirmar a especificação Jaguar.",
                        "Tabelas de fabricante (MAHLE/AutoAir) + nota EV"),
                of(Status.OFICIAL, "Direção assistida",
                        "Elétrica (EPAS) — NÃO tem óleo de direção.",
                        "Especificação Jaguar"),
                of(Status.INCERTO, "Óleo das unidades de tração (EDU)",
                        "Lubrificante da redução não especificado publicamente e sem intervalo oficial — ver secção Manutenção.",
                        "Sem fonte oficial pública"));

        // =========================== BATERIAS 12V ===========================
        section("bat12v", "Baterias de 12V (especificações)",
                "A parte com mais confusão na internet. Aqui vai o que está confirmado.",
                of(Status.COMUNIDADE, "Principal / de arranque (a maior)",
                        "Chumbo-ácido CONVENCIONAL (inundada/«flooded»), tipo 063, ~47 Ah, 420-450 A (CCA). Equivalente Exide EA472; OEM Jaguar "
                        + "T4K4462. NÃO é AGM, apesar do que o manual sugere.",
                        "Fóruns i-Pace + catálogos (OEM T4K4462)"),
                of(Status.COMUNIDADE, "Auxiliar (a pequena)",
                        "AGM, 12 V, 15 Ah, 200 A (CCA). Exide EK151 (ref. JLR CX23-10C655-AC, tamanho C56). Uma auxiliar fraca provoca muitos "
                        + "erros elétricos estranhos, incluindo o aviso «Reduced Brake Pedal Feel».",
                        "Catálogos (Exide EK151) + fóruns i-Pace"),
                of(Status.COMUNIDADE, "Quantas e onde",
                        "Pré-2021: DUAS baterias de 12V no frunk (principal + auxiliar). MY21+ pode ter só uma — confirmar no carro.",
                        "Fóruns i-Pace"),
                of(Status.COMUNIDADE, "Cuidado com o manual",
                        "O manual diz «está instalada uma bateria AGM». Verdade para a auxiliar; a principal/de arranque é inundada — daí a "
                        + "confusão online.",
                        "Fóruns i-Pace"),
                of(Status.COMUNIDADE, "Substituição e arranque auxiliar",
                        "Substituir pela etiqueta de cada bateria. Arranque auxiliar só com packs convencionais de chumbo-ácido, NUNCA de lítio. "
                        + "Muitas falhas atribuídas à 12V são software desatualizado — atualizar antes de condenar a bateria.",
                        "Comunidade i-Pace / boas práticas"));

        // ===================== ACESSO / ARRANQUE / EMERGÊNCIA ================
        section("acesso", "Acesso, arranque e emergências da 12V",
                "O que fazer quando a 12V está fraca ou morta — abrir o capô sem energia, chegar às baterias e dar arranque auxiliar.",
                of(Status.OFICIAL, "Abrir o capô SEM energia",
                        "Se a 12V está morta e o frunk não abre: tampa cilíndrica no fundo do pé do passageiro (lado de fora, por baixo do "
                        + "porta-luvas) — rodar no sentido anti-horário e puxar o cabo de emergência; depois levantar o trinco de segurança do capô.",
                        "Manual (iGuide) + fóruns i-Pace"),
                of(Status.COMUNIDADE, "Chegar às baterias",
                        "As 12V estão no frunk. Remover o tabuleiro (scuttle) e desencaixar os painéis laterais, rodando-os à volta dos "
                        + "amortecedores do capô — dá bom espaço para as duas. A principal é mais apertada (grampos).",
                        "Fóruns i-Pace"),
                of(Status.COMUNIDADE, "Trocar a 12V em segurança",
                        "Portas destrancadas e capô aberto até o interruptor dos piscas apagar/esmaecer (~20-30 min = carro «a dormir»). Soltar "
                        + "primeiro a massa (corpo→bateria) e isolar a ponta. Chaves 8/10/13 mm. Apertar ~12 Nm. Cuidado: a HV carrega a 12V.",
                        "Fóruns i-Pace (jaginfo/ipaceforums)"),
                of(Status.COMUNIDADE, "Arranque auxiliar (jump)",
                        "Ligar + ao + da bateria e a massa (−) a um ponto metálico/haste acima da bateria, virado para a antepara. Esperar "
                        + "10-15 min depois de alimentar, para os computadores acordarem. O i-Pace não serve bem como dador de outro carro.",
                        "Manual + fóruns i-Pace"),
                of(Status.OFICIAL, "Chave não reconhecida",
                        "Se a pilha do comando estiver fraca: encostar o comando (botões virados ao chão) à parte de baixo da coluna da direção, "
                        + "pisar o travão e arrancar.",
                        "Procedimento JLR / fóruns"));

        // =========================== BATERIA SOS ============================
        section("sos", "Bateria SOS / eCall (TCU)",
                "A chamada de emergência (SOS/eCall) tem a sua própria bateria de reserva dentro do módulo de telemática (TCU). Falha com a idade.",
                of(Status.COMUNIDADE, "O que é e para que serve",
                        "Pequena bateria recarregável DENTRO do módulo de telemática (TCU) — não é uma bateria solta na mala. Permite fazer a "
                        + "chamada de emergência mesmo que a 12V seja cortada num acidente.",
                        "Guias JLR/TCU + fóruns i-Pace"),
                of(Status.COMUNIDADE, "Onde fica",
                        "No i-Pace, o TCU fica no lado ESQUERDO da zona de carga (mala), atrás do revestimento. Chegar lá implica normalmente "
                        + "retirar o banco traseiro, soltar parafusos escondidos e desencaixar o trim. (Documentos JLR genéricos falam da consola "
                        + "do teto noutros modelos — confirmar no carro.)",
                        "Fóruns i-Pace (ipaceforums)"),
                of(Status.COMUNIDADE, "Que bateria é",
                        "Recarregável pequena, normalmente lítio-ião ou NiMH, vida útil ~3-5 anos. Referência citada: LR089861. Item substituível "
                        + "e barato — não é preciso trocar o módulo todo.",
                        "Especialistas eCall + catálogos (LR089861)"),
                of(Status.COMUNIDADE, "Erros que dá",
                        "Aviso «SOS System Limited Functionality» / «SOS Limited Availability» / «SOS Not Available». Códigos: U2109 (também "
                        + "B15CC/B15EC). A app MyJaguar pode mostrar a tensão do TCU a 0%.",
                        "TSB Jaguar SSM75646 (2022) + fóruns"),
                of(Status.COMUNIDADE, "Porque não carrega",
                        "A bateria do TCU só carrega com o carro a andar ou em modo READY. Pode limpar sozinho após várias viagens; se persistir, "
                        + "chegou ao fim.",
                        "Fóruns i-Pace"),
                of(Status.COMUNIDADE, "Substituição",
                        "Trocar a célula e limpar a falha com scanner. Erro caro comum: trocar o TCU todo quando é só a bateria. IDs de oficina "
                        + "JLR citados: 5669 (aceder ao TCU) e 5675 (trocar a bateria).",
                        "Fóruns i-Pace + especialistas"));

        // ============================ CARREGAMENTO ===========================
        section("carreg", "Carregamento (AC e DC)",
                "Como o i-Pace carrega de verdade — e um truque muito útil para a carga rápida.",
                of(Status.OFICIAL, "AC (casa / poste)",
                        "MY2019-2020: carregador de bordo monofásico 32 A ≈ 7,4 kW. Opção/mercados com trifásico até 11 kW (precisa de "
                        + "alimentação trifásica em casa). Conector Tipo 2.",
                        "Fichas Jaguar + fóruns i-Pace"),
                of(Status.COMUNIDADE, "DC rápida (CCS)",
                        "Pico ~100-104 kW só com bateria baixa e quente; cai depressa para ~80 kW. Média real 10-80% ~72 kW. Máx. ~250 A, "
                        + "380-450 V. 0-80% ~40 min em boas condições.",
                        "evkx + fóruns i-Pace"),
                of(Status.COMUNIDADE, "Truque dos piscas (hazard)",
                        "Para segurar os 100 kW numa estação HPC, ligar os quatro piscas ANTES de ligar o cabo — é uma instrução de serviço "
                        + "Jaguar ligada ao balanceamento. Sem isto, muitos carros caem a ~80 kW passados ~2 min.",
                        "goingelectric + fóruns i-Pace"),
                of(Status.COMUNIDADE, "Luz do port e fim de carga",
                        "Em carga, o anel do port pisca (verde nas versões mais recentes). Em DC a 100%, fica verde fixo e o cabo sai sem "
                        + "destrancar. Frio e SoC alto reduzem muito a potência.",
                        "Fóruns i-Pace"),
                of(Status.COMUNIDADE, "Boas práticas",
                        "Diário 20-80%; 100% só quando precisa (ajuda a reequilibrar de vez em quando). Pré-condicionar ligado à corrente. DC "
                        + "frequente acelera a degradação — usar sobretudo em viagem.",
                        "Boa prática EV / comunidade"));

        // ====================== AUTONOMIA / EFICIÊNCIA / FRIO ================
        section("alcance", "Autonomia, eficiência & frio",
                "Números reais de autonomia e consumo, e a questão (contestada) do aquecimento no frio.",
                of(Status.OFICIAL, "Bateria & motores",
                        "90 kWh nominais / ~84,7 kWh utilizáveis; 432 células de iões de lítio em 36 módulos. Dois motores (AWD), ~294 kW (400 cv).",
                        "Jaguar / imprensa"),
                of(Status.OFICIAL, "Autonomia homologada",
                        "WLTP ~470 km (292 milhas). EPA inicial 234 milhas, subiu para 246 (396 km) com atualização de software em dez/2019.",
                        "Jaguar / Wikipedia / EPA"),
                of(Status.COMUNIDADE, "Autonomia real",
                        "Tipicamente ~2,1-3,0 mi/kWh (~18-30 kWh/100 km). Real ~350-400 km no verão a velocidade moderada; bastante menos em "
                        + "autoestrada e no frio. A ~110 km/h assume-se ~26 kWh/100 km.",
                        "Testes + fóruns i-Pace"),
                of(Status.COMUNIDADE, "Frio & aquecimento (contestado)",
                        "O i-Pace aquece o habitáculo sobretudo por resistência de alta tensão (consome muito). Se tem ou não «bomba de calor» é "
                        + "tema contestado: umas fontes dizem que usa o circuito do A/C como bomba de calor, outras que não tem. Curiosamente, um "
                        + "estudo (Recurrent) mediu só ~3% de perda no frio; outro (NAF) ~24%. Dica: pré-condicionar ligado à corrente e usar "
                        + "banco/volante aquecidos.",
                        "Recurrent/NAF + fóruns (contestado)"));

        // ======================= SAÚDE & DEGRADAÇÃO ==========================
        section("degradacao", "Saúde da bateria & degradação",
                "O que dizem os dados reais sobre a durabilidade do pack — e a garantia.",
                of(Status.COMUNIDADE, "Degradação real",
                        "Tipicamente ~2% ao ano; muitos carros com ~90% de SoH aos 100.000 km, e vários a 92-94% mesmo com uso intenso. A perda é "
                        + "maior no início e depois abranda. DC frequente acelera um pouco.",
                        "Dados agregados + fóruns i-Pace"),
                of(Status.OFICIAL, "Garantia da bateria HV",
                        "8 anos / 160.000 km (100.000 milhas), cobrindo defeitos e a saúde (SoH) cair abaixo de 70%, medida por concessionário "
                        + "Jaguar certificado. Confirmar no livrete (varia por mercado).",
                        "Documentação de garantia Jaguar UK"),
                of(Status.COMUNIDADE, "Capacidade limitada por campanha",
                        "Alguns carros sob campanha da bateria ficaram limitados (ex.: ~80% ou ~72% de capacidade) até à reparação — pode "
                        + "acontecer mesmo com um pack saudável. Verificar o estado das campanhas pelo VIN.",
                        "Fóruns i-Pace"));

        // ===================== OBD / PIDs DA COMUNIDADE ======================
        section("obd", "Diagnóstico OBD & PIDs da comunidade",
                "Porque é difícil ler dados no i-Pace e o que a comunidade conseguiu (não oficial).",
                of(Status.COMUNIDADE, "Porta OBD fechada pelo gateway",
                        "A tomada OBD liga ao Gateway (GWM): os PIDs OBD standard dão muito pouco no i-Pace. Para ler célula/SoC/temperaturas é "
                        + "preciso UDS (ISO 14229) nos endereços certos, ou «sniffar» o CAN atrás do gateway.",
                        "evmetrics + fóruns i-Pace"),
                of(Status.COMUNIDADE, "PIDs reverse-engineered (não oficiais)",
                        "A comunidade (OVMS, evmetrics, fóruns) mapeou PIDs no header 7E4 (BECM). Exemplos citados: 22 490F = tensão da bateria, "
                        + "fórmula int16(A:B)/100; temperaturas da bateria 0x492B-0x4930; temperaturas dos pneus 0x2A0A-0x2A0D (valor−50); contador "
                        + "de energia 0x4912. NÃO oficiais — confirmar no carro.",
                        "OVMS (openvehicles) + fóruns"),
                of(Status.COMUNIDADE, "Apps e hardware da comunidade",
                        "Ferramentas usadas: OVMS (tem suporte i-Pace), Torque Pro com PIDs personalizados (prefixo 22, header 7E4), WattCat, e "
                        + "módulos como o Macaron para SoH/temperaturas. Esta app (VoltDiag) usa a mesma técnica UDS, só de leitura.",
                        "Fóruns i-Pace / OVMS"));

        // ================= MENU DE ENGENHARIA / MODOS DE SERVIÇO ============
        section("modos", "Menu de engenharia & modos de serviço",
                "Menus escondidos e os modos que convém conhecer.",
                of(Status.COMUNIDADE, "Menu de engenharia (ecrã)",
                        "Em sistemas InControl Touch Pro, encostar o dedo ao canto superior-central do ecrã ~15 s abre um menu de engenharia com "
                        + "as versões de hardware/software dos módulos. Varia com o sistema (ICTP vs Pivi Pro) e é pouco útil sem tabela de "
                        + "referência das versões.",
                        "Fóruns JLR (F-Pace/I-Pace) — confirmar"),
                of(Status.OFICIAL, "Modo de Serviço / Transporte",
                        "Pela app InControl Remote ou site My Jaguar: evita alarmes de roubo durante serviço ou transporte (ex.: barco). Serviço "
                        + "até 72 h; não se ativa dentro do carro.",
                        "Jaguar (emergency & security features)"));

        // =============================== PNEUS ==============================
        section("pneus", "Pneus & rodas",
                "Medidas de origem, pressões e notas práticas.",
                of(Status.OFICIAL, "Medidas",
                        "Três medidas de origem: 235/65 R18, 245/50 R20 e 255/40 R22, conforme a jante. Furação (PCD) 5×108, centro 63,4 mm.",
                        "Michelin / wheel-size"),
                of(Status.OFICIAL, "Pressões",
                        "Cerca de 2,5 bar (≈36-37 psi); alguns valores de origem diferem à frente/atrás (ex.: 20\": 2,5 à frente / 2,2 atrás). "
                        + "Confirmar SEMPRE na etiqueta da ombreira da porta do condutor.",
                        "Michelin UK / etiqueta do carro"),
                of(Status.COMUNIDADE, "Na prática",
                        "Pneus largos e caros (um jogo de 22\" Pirelli pode passar de €1000). O peso e o binário gastam depressa — rotação e "
                        + "pressão certa ajudam muito.",
                        "Comunidade i-Pace"));

        // ============================ SOFTWARE / OTA ========================
        section("software", "Software & OTA",
                "Os dois sistemas do i-Pace e porque convém estar sempre atualizado.",
                of(Status.COMUNIDADE, "Dois sistemas",
                        "Até meados de 2021: InControl Touch Pro (ICTP), mais lento. MY21+: Pivi Pro, mais rápido e com OTA (SOTA) muito melhor. "
                        + "É a grande linha divisória do i-Pace.",
                        "go-parts + comunidade"),
                of(Status.COMUNIDADE, "Versões (referência)",
                        "Pivi Pro: 2.0.x (2021) → 3.0 (dez/2021, CarPlay/Android Auto sem fios) → 3.2 → 4.x mais tarde. No carro: Definições → "
                        + "Todas as definições → Atualização de software (ICTP em cima; BECS/TCU em baixo).",
                        "Fóruns i-Pace"),
                of(Status.OFICIAL, "Porque importa",
                        "Manter atualizado corrige muitos problemas (12V, climatização, carga, BECM). Uma atualização passou a permitir OTA com o "
                        + "carro a carregar em AC. Atualizações falhadas podem deixar o sistema inconsistente (ida ao concessionário).",
                        "Notas de versão Jaguar + comunidade"));

        // ============================== DICAS ===============================
        section("dicas", "Dicas & truques",
                "Boas práticas da comunidade para tirar o melhor do i-Pace e evitar chatices.",
                of(Status.COMUNIDADE, "Carregamento do dia-a-dia",
                        "Manter ~20-80% no uso diário; evitar deixar muito tempo a 100% ou perto de 0%. 100% só quando precisa da autonomia toda.",
                        "Boa prática EV / comunidade"),
                of(Status.COMUNIDADE, "Pré-condicionamento ligado à corrente",
                        "Pré-condicionar habitáculo (e bateria, no frio) com o carro ligado ao carregador poupa autonomia e melhora a carga rápida.",
                        "Comunidade i-Pace"),
                of(Status.COMUNIDADE, "Exercitar os travões",
                        "Travar com firmeza algumas vezes por semana (em segurança) para limpar ferrugem dos discos.",
                        "Comunidade i-Pace"),
                of(Status.COMUNIDADE, "Antes de condenar seja o que for",
                        "Muitos problemas (carga, avisos, módulos) resolvem-se com um reset/sleep cycle e com o software atualizado. Ver «Resets».",
                        "Comunidade i-Pace"));

        // ======================= MANIAS / PEQUENOS DEFEITOS =================
        section("quirks", "Manias e pequenos defeitos",
                "Coisas conhecidas mas menores — bom saber que não é só o seu carro.",
                of(Status.COMUNIDADE, "Travões a chiar",
                        "Chiadeira dos travões é relato frequente (por vezes dita «normal»); ligada ao pouco uso/ferrugem — ver manutenção dos "
                        + "travões.",
                        "Fóruns i-Pace"),
                of(Status.COMUNIDADE, "Assistência à faixa «fantasma»",
                        "O Lane Keep pode seguir fissuras no alcatrão ou sombras e puxar a direção — desativável.",
                        "Fóruns i-Pace"),
                of(Status.COMUNIDADE, "Definições que se apagam",
                        "Alguns relatam perda de perfis de rádio/banco; muitas vezes ligado a 12V fraca ou software antigo.",
                        "Fóruns i-Pace"),
                of(Status.COMUNIDADE, "HUD e infotainment pré-facelift",
                        "Head-up display com queixas pontuais; o ICTP (pré-Pivi) é lento ou reinicia — melhora muito com o Pivi Pro e atualizações.",
                        "Fóruns i-Pace"),
                of(Status.COMUNIDADE, "Trinco do capô (TSB)",
                        "Houve um TSB ao trinco do capô que causava problemas de carga/fecho — resolvido por substituição.",
                        "Fóruns i-Pace / TSB"));

        // ============================ MITOS =================================
        section("mitos", "Mitos vs factos",
                "Separar o boato do facto, confirmando sempre no seu caso concreto.",
                of(Status.COMUNIDADE, "«A bateria degrada-se muito depressa»",
                        "Mito, na maioria dos casos — ~2% ao ano e muitos carros a 90-95% de SoH após anos. Ver a secção «Saúde da bateria».",
                        "Dados reais + fóruns i-Pace"),
                of(Status.OFICIAL, "«Um EV não precisa de manutenção»",
                        "Mito. Menos que um ICE, mas não zero: travões, líquidos, filtro de habitáculo, pneus e software atualizado.",
                        "Plano de serviço Jaguar"),
                of(Status.COMUNIDADE, "«É um carro pouco fiável»",
                        "Meio-verdade. Teve problemas reais (software/BECM, 12V, aquecedor, infiltrações), muitos resolvidos por atualização ou "
                        + "campanha. Os piores anos são 2019-2020; a maioria dos donos de longa data diz que estabiliza. Construído pela Magna "
                        + "Steyr (Graz) e Carro Mundial do Ano 2019.",
                        "Imprensa + comunidade (visão equilibrada)"),
                of(Status.COMUNIDADE, "«Carregar sempre a 100% não faz mal»",
                        "Mito no uso diário. Ocasional é inofensivo (e às vezes útil para reequilibrar), mas sempre a 100% acelera a degradação. "
                        + "No dia-a-dia, 80% chega.",
                        "Boa prática EV / comunidade"));

        // ============================ RESETS ================================
        section("resets", "Resets & procedimentos",
                "Procedimentos seguros para destravar situações comuns. Nenhum altera o carro — são ações de utilizador.",
                of(Status.OFICIAL, "Sleep cycle (reset suave)",
                        "Trancar o carro e esperar que a rede adormeça (modo de repouso). A Jaguar usa isto no diagnóstico (SSM74274). Na prática: "
                        + "trancar, afastar-se, esperar 10-30 min, destrancar e tentar de novo. Resolve muitas falhas estranhas e de carga.",
                        "Jaguar SSM74274 + comunidade"),
                of(Status.COMUNIDADE, "Reset pelo botão de arranque",
                        "Manter o botão START premido ~10 s SEM carregar no travão força um reinício da eletrónica.",
                        "Comunidade i-Pace"),
                of(Status.COMUNIDADE, "Reset forçado pela 12V",
                        "Desligar a 12V durante 10-15 min força um reinício completo. Fazer com cuidado (idealmente em oficina) — pode exigir "
                        + "reaprendizagens.",
                        "Comunidade i-Pace"),
                of(Status.OFICIAL, "Cabo de carga preso — AC (Tipo 2)",
                        "Destrancar o carro: normalmente o cabo liberta. ~60 s para o retirar antes de o trinco voltar a fechar.",
                        "Manual + comunidade"),
                of(Status.OFICIAL, "Cabo de carga preso — DC rápida (CCS)",
                        "Premir DESTRANCAR na chave DUAS vezes; esperar ~6 s até o trinco libertar; retirar em 60 s (depois volta a trancar). "
                        + "Premir uma só vez durante a carga DC só destranca as portas.",
                        "Manual do proprietário i-Pace"),
                of(Status.OFICIAL, "Libertação manual do cabo",
                        "Argola/puxador VERMELHO no frunk (canto do lado do condutor) recolhe o pino de bloqueio. NUNCA puxar o cabo à força — "
                        + "parte o pino/clipe do conetor.",
                        "Manual + comunidade"));
    }

    public static List<Section> all() { return SECTIONS; }

    public static Section byId(String id) {
        for (Section s : SECTIONS) if (s.id.equals(id)) return s;
        return null;
    }

    /** Rótulo curto do estatuto, para a interface e o PDF. */
    public static String statusLabel(Status s) {
        switch (s) {
            case OFICIAL: return "Oficial";
            case COMUNIDADE: return "Comunidade";
            default: return "Não confirmado";
        }
    }

    public static int sectionCount() { return SECTIONS.size(); }

    public static int itemCount() {
        int n = 0;
        for (Section s : SECTIONS) n += s.items.size();
        return n;
    }
}
