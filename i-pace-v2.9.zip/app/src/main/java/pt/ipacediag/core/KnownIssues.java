package pt.ipacediag.core;

import java.util.ArrayList;
import java.util.List;

/**
 * Recalls e falhas conhecidas do Jaguar I-Pace.
 *
 * Distingue o que a JLR assumiu oficialmente (RECALL / boletim TSB-SSM) do que é
 * reportado pela comunidade. Os recalls aqui são as campanhas globais da JLR (números
 * "H…") com a referência NHTSA (EUA); em Portugal/UE, o dono deve confirmar pelo VIN
 * junto da JLR Portugal / IMT, porque a elegibilidade e as datas podem diferir.
 *
 * Factos resumidos por nós a partir de registos públicos (NHTSA/ODI e imprensa);
 * atualizado em 2026-11-25. Rever periodicamente — a lista evolui.
 */
public final class KnownIssues {
    private KnownIssues() {}

    public enum Kind { RECALL, TSB, COMMUNITY }

    public static final class Issue {
        public final Kind kind;
        public final String ref;      // nº de campanha JLR / código
        public final String title;
        public final String date;     // data de referência
        public final String models;   // anos abrangidos
        public final String desc;     // o que é
        public final String remedy;   // o que fazem/fazer
        public final String source;   // fonte (ex.: NHTSA 24V633)

        Issue(Kind kind, String ref, String title, String date, String models, String desc, String remedy, String source) {
            this.kind = kind; this.ref = ref; this.title = title; this.date = date;
            this.models = models; this.desc = desc; this.remedy = remedy; this.source = source;
        }
    }

    private static final List<Issue> LIST = new ArrayList<>();
    static {
        // --- RECALLS: saga do sobreaquecimento da bateria de alta tensão ---
        r("H572", "Bateria AT pode sobreaquecer — remédio mais recente", "2024 (aviso: estacionar no exterior)",
                "2020–2021 (e substitui campanhas anteriores)",
                "Risco de sobreaquecimento/incêndio da bateria de alta tensão. Substitui as campanhas 23V369, 23V709 e 24V085; a JLR aconselhou estacionar no exterior, longe de edifícios.",
                "Remédio novo obrigatório mesmo em carros já reparados nas campanhas anteriores. Confirmar elegibilidade pelo VIN.",
                "JLR H570/H571/H572; imprensa 2024");
        r("H514 / H536", "Substituição da bateria de alta tensão", "notificação 26-06-2024 (H514v7: 11-09-2025)",
                "2019 (fabricados em Graz 09-01-2018 a 14-03-2019)",
                "Reparação provisória anterior incorreta; mantém-se o risco de sobreaquecimento/incêndio.",
                "Substituição da bateria de alta tensão, sem custos. ~2760 viaturas nos EUA.",
                "NHTSA 24V633 (JLR H514)");
        r("H471", "Módulo BECM reparado incorretamente", "08-02-2024 (H471v3)",
                "2019–2024",
                "Reparação do BECM feita de forma incorreta mantém o risco de sobreaquecimento.",
                "Nova atualização/verificação do BECM, sem custos.",
                "NHTSA 24V085 (JLR H471)");
        r("H459", "Repetição da atualização de software do BECM", "18-10-2023",
                "sobretudo 2021 (carros já sob 23V369)",
                "A reparação anterior (23V369) pode não ter ficado bem concluída.",
                "Atualizar de novo o software do BECM, sem custos. ~501 viaturas.",
                "NHTSA 23V709 (JLR H459)");
        r("H441", "Atualização de software do BECM", "25-05-2023 (notificação 18-07-2023)",
                "2019–2024",
                "A bateria de alta tensão pode sobreaquecer. Primeira grande campanha de software do BECM.",
                "Atualização do software do BECM, sem custos. ~6422 viaturas.",
                "NHTSA 23V369 (JLR H441)");
        r("H468", "Fixadores do módulo da bateria aos barramentos", "08-02-2024",
                "2019–2020",
                "Os fixadores que seguram o módulo da bateria aos barramentos podem não estar bem apertados, causando arco elétrico.",
                "Inspeção/aperto, sem custos.",
                "NHTSA 24V086 (JLR H468)");
        r("AVAS", "Som de aviso a peões insuficiente", "2024",
                "2021–2022",
                "O veículo pode não emitir som de aviso suficiente parado e em marcha-atrás (sistema AVAS).",
                "Atualização de software, sem custos.",
                "NHTSA (recall AVAS I-Pace)");
        r("H213", "Travão regenerativo — atraso na travagem", "início 12-06-2019",
                "2019–2020 (fabricados ~23-08-2017 a 11-04-2019)",
                "Se o sistema de travagem regenerativa falhar, há um atraso maior entre carregar no travão e o carro abrandar — não cumpre a norma FMVSS 135. ~3083 viaturas (EUA).",
                "Atualização de software no concessionário, sem custos. Confirmar pelo VIN.",
                "NHTSA 19V351 (JLR H213)");

        // --- TSB / boletins técnicos ---
        t("P0AA6-1A", "Falha de isolamento HVIL (BECM)", "boletim técnico",
                "2019–2024",
                "Código P0AA6 registado no BECM como falha de isolamento de alta tensão (HVIL). Pode surgir com humidade/água nos conectores de AT, sobretudo em carregamento rápido.",
                "Diagnóstico guiado JLR; confirmar se a atualização H441 do BECM foi aplicada; documentar dentro da garantia.");
        t("A/C tubos", "A/C não arrefece — tubos do compressor rachados na solda", "boletim técnico (19MY→)",
                "2019 em diante",
                "O ar condicionado deixa de arrefecer por fuga de gás nos tubos de entrada/saída do compressor, que racham na SOLDA por baixa qualidade de soldadura.",
                "A Jaguar tem tubos redesenhados e manda substituir SEMPRE os dois, mesmo que só um tenha fuga. Reparação por oficina.");
        t("SSM74851", "A/C — fuga lenta no condensador", "boletim técnico",
                "I-PACE",
                "Parafuso de fixação do tubo do condensador que não aperta bem (tolerâncias) provoca uma fuga lenta de gás e perda gradual de arrefecimento.",
                "Correção com anilha/aperto correto, por oficina. Recarregar o gás após reparar.");
        t("SSM76342", "Para-brisas — defeitos no vidro", "boletim técnico",
                "I-PACE / E-PACE",
                "A JLR reconheceu relatos de defeitos no para-brisas (distorções/marcas no vidro).",
                "Avaliação em concessionário; substituição do para-brisas se confirmado dentro de critério.");
        t("H448 / H525", "Aquecedor de alta tensão (HVCH) — sem aquecimento", "recall/ação 2019–2023",
                "2019–2023",
                "Falha do elemento interno do aquecedor de líquido de alta tensão (HVCH): o carro fica sem aquecimento do habitáculo (e pode não desembaciar o para-brisas). Código típico B1DC5-93 (\"HVCH #1 - No operation\": o módulo bloqueia após demasiadas falhas). Recall H448 cobre o desembaciamento em vários modelos.",
                "Substituição do HVCH por oficina — trabalho GRANDE (obriga a baixar o pack de alta tensão) e caro; não é DIY. Confirmar elegibilidade do recall pelo VIN.");
        t("SSM75646", "SOS / eCall — bateria de backup do TCU fraca", "boletim técnico (18-01-2022)",
                "2019 em diante",
                "O módulo de telemática (TCU3) gera o aviso «SOS Limited Availability / Not Available» no quadrante porque a bateria de backup interna (BuB) está fraca. Códigos típicos: U2109 (também B15CC/B15EC). A bateria do TCU fica no lado esquerdo da zona de carga.",
                "Substituir a bateria de backup do TCU (não o módulo todo) e limpar a falha com scanner. A bateria só carrega com o carro a andar/READY. Ver «Conhecimento → Bateria SOS».");

        // --- Reportado pela comunidade (não oficial) ---
        c("12V", "Descarga/falha da bateria de 12V", "comunidade",
                "todos (sobretudo pré-2021, duas baterias)",
                "Falhas e descarga das baterias de 12V são o relato MAIS comum: carro «morto» de manhã, não arranca/não desbloqueia, carrega devagar ou não carrega, e avisos aleatórios de «System Failure», «Traction Battery Fault» ou «Reduced Brake Pedal Feel». Códigos associados: U3003, P1A04. Muito ligado a software desatualizado e ao fim de vida aos ~3 anos.",
                "Atualizar o software primeiro; testar AMBAS as 12V (principal flooded 063 + auxiliar AGM Exide EK151) e substituir as fracas. Ver «Conhecimento → Baterias de 12V / Acesso».");
        c("InControl", "Falhas do InControl Touch Pro (infotainment)", "comunidade",
                "sobretudo pré-facelift",
                "Bloqueios, reinícios e lentidão do sistema de infotainment são relatos comuns na comunidade.",
                "Atualizações de software (OTA/oficina); reinício do sistema. Não acessível por OBD.");
        c("Água", "Infiltrações de água (para-brisas, pés, frunk)", "comunidade",
                "vários",
                "Relatos de água a entrar: pelo para-brisas, tapetes/pés molhados (muitas vezes por dreno do evaporador do A/C entupido) e "
                + "entrada de água no frunk (compartimento dianteiro).",
                "Desentupir e limpar os drenos (para-brisas/teto/evaporador); verificar vedantes e a drenagem do frunk; secar e procurar a origem.");
        c("Travões", "Travões de fricção a gripar/enferrujar", "comunidade",
                "todos",
                "Consequência do pouco uso por causa da travagem regenerativa: discos e pinças enferrujam e podem gripar.",
                "Usar os travões de fricção com firmeza de vez em quando; inspeção e limpeza/lubrificação das pinças. Ver «Conhecimento → Manutenção».");
        c("Cabo de carga", "Cabo de carga preso / não tranca", "comunidade",
                "todos",
                "O cabo não tranca (não arranca a carga) ou fica preso após carregar. Muitas vezes ligado a 12V fraca ou a trinco do conector.",
                "Destrancar (no DC, duas vezes e esperar 6 s); se preso, usar a argola vermelha no frunk. Ver «Conhecimento → Resets». Nunca forçar o cabo.");
        c("Porta de carga", "Falha da porta/atuador de carregamento", "comunidade",
                "sobretudo 2019–2020",
                "A tampa não abre ou o pino do trinco não desce/sobe (falha do chip/atuador): o carro não reconhece o cabo e não carrega. Às vezes basta um fusível (caixa dianteira nº1, posição 1, 5A).",
                "Verificar o fusível; libertar o cabo pela argola vermelha do frunk. Se o atuador falhou, é substituição da porta de carga (peça pode demorar).");
        c("Carregador de bordo (OBC)", "Falha do carregador de bordo", "comunidade",
                "todos",
                "Falha interna do carregador de bordo (OBC): aviso de sistema de alta tensão e incapacidade total de carregar, sem resposta do port.",
                "Diagnóstico de oficina; normalmente substituição do conjunto do OBC. Não é DIY (alta tensão).");
        c("Contactor HV", "Aviso de falha de contactor de alta tensão", "comunidade",
                "vários",
                "Mensagens de aviso do sistema de alta tensão (contactor). Pode ser intermitente; alguns casos são reparação cara.",
                "Diagnóstico guiado JLR; documentar dentro da garantia. Confirmar antes 12V e software.");
        c("Chassis", "Apoios de motor / cremalheira da direção", "comunidade",
                "vários (menos frequente)",
                "Relatos menos frequentes de ruídos/folgas ligados a apoios de motor e, nalguns casos, à cremalheira/motor de direção.",
                "Inspeção em oficina; substituição da peça afetada se confirmada.");
    }

    private static void r(String ref, String title, String date, String models, String desc, String remedy, String source) {
        LIST.add(new Issue(Kind.RECALL, ref, title, date, models, desc, remedy, source));
    }
    private static void t(String ref, String title, String date, String models, String desc, String remedy) {
        LIST.add(new Issue(Kind.TSB, ref, title, date, models, desc, remedy, "JLR TOPIx (boletim)"));
    }
    private static void c(String ref, String title, String date, String models, String desc, String remedy) {
        LIST.add(new Issue(Kind.COMMUNITY, ref, title, date, models, desc, remedy, "comunidade I-Pace"));
    }

    public static List<Issue> all() { return LIST; }

    public static List<Issue> byKind(Kind k) {
        List<Issue> out = new ArrayList<>();
        for (Issue i : LIST) if (i.kind == k) out.add(i);
        return out;
    }

    public static int count() { return LIST.size(); }
}
