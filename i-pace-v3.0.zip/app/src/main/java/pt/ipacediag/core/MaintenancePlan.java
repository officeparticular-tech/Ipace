package pt.ipacediag.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Lembretes de manutenção do I-Pace a partir da quilometragem lida ao carro.
 * Baseia-se no plano oficial Jaguar (revisão a cada 2 anos / ~34.000 km) e em boas
 * práticas da comunidade. Pura Java (testável sem Android).
 *
 * Os itens por QUILOMETRAGEM têm contagem decrescente; os itens por TEMPO (líquido de
 * travões ~3 anos, filtro de habitáculo ~2 anos) não se calculam só com os km — ficam
 * como referência, porque dependem da data da última intervenção.
 */
public final class MaintenancePlan {
    private MaintenancePlan() {}

    public enum Level { OK, SOON, DUE, INFO }

    public static final class Item {
        public final String name;     // o que é
        public final String interval; // intervalo recomendado
        public final String due;      // "Faltam X km" / "Em atraso …" / referência de tempo
        public final Level level;
        public final boolean km;      // true = calculado por quilometragem
        Item(String name, String interval, String due, Level level, boolean km) {
            this.name = name; this.interval = interval; this.due = due; this.level = level; this.km = km;
        }
    }

    public static final int SERVICE_KM = 34000;   // revisão oficial (ou 2 anos)
    public static final int ROTATION_KM = 10000;  // rotação de pneus (boa prática)
    public static final int COOLANT_KM = 145000;  // líquido de arrefecimento HV (~5 anos)

    /**
     * @param odoKm        quilometragem atual (NaN se desconhecida)
     * @param lastServiceKm km da última revisão, se o utilizador os definiu (NaN se não)
     */
    public static List<Item> compute(double odoKm, double lastServiceKm) {
        List<Item> out = new ArrayList<>();
        boolean haveOdo = !Double.isNaN(odoKm) && odoKm >= 0;

        // Revisão oficial — âncora nos km da última revisão, se existirem; senão no múltiplo de 34.000
        if (haveOdo) {
            double base = (!Double.isNaN(lastServiceKm) && lastServiceKm >= 0)
                    ? lastServiceKm : Math.floor(odoKm / SERVICE_KM) * SERVICE_KM;
            double next = base + SERVICE_KM;
            out.add(kmItem("Revisão oficial Jaguar", "2 anos / 34.000 km", odoKm, next));
        } else {
            out.add(new Item("Revisão oficial Jaguar", "2 anos / 34.000 km",
                    "Leia os km do carro para calcular.", Level.INFO, true));
        }

        // Rotação de pneus
        if (haveOdo) {
            double next = Math.floor(odoKm / ROTATION_KM) * ROTATION_KM + ROTATION_KM;
            out.add(kmItem("Rotação dos pneus", "~10.000 km", odoKm, next));
        }

        // Líquido de arrefecimento da bateria HV
        if (haveOdo) {
            double next = Math.floor(odoKm / COOLANT_KM) * COOLANT_KM + COOLANT_KM;
            out.add(kmItem("Líquido de arrefecimento (bateria HV)", "~5 anos / 145.000 km", odoKm, next));
        }

        // Itens por tempo — não calculáveis só com km
        out.add(new Item("Líquido de travões", "~3 anos",
                "Depende da data da última mudança (~3 anos).", Level.INFO, false));
        out.add(new Item("Filtro de habitáculo (pólen)", "~2 anos",
                "Depende da data da última mudança (~2 anos).", Level.INFO, false));
        out.add(new Item("Travões de fricção (inspeção/limpeza)", "anual",
                "Inspeção anual; usar os travões com firmeza de vez em quando (pouco uso pela regeneração).", Level.INFO, false));

        return out;
    }

    private static Item kmItem(String name, String interval, double odo, double next) {
        double remaining = next - odo;
        Level lv; String due;
        if (remaining < 0) {
            lv = Level.DUE;
            due = String.format(Locale.US, "Em atraso ~%,d km (prevista aos %,d km)", (long) -remaining, (long) next);
        } else if (remaining <= 2000) {
            lv = Level.SOON;
            due = String.format(Locale.US, "Brevemente: faltam ~%,d km (aos %,d km)", (long) remaining, (long) next);
        } else {
            lv = Level.OK;
            due = String.format(Locale.US, "Faltam ~%,d km (aos %,d km)", (long) remaining, (long) next);
        }
        return new Item(name, interval, due, lv, true);
    }
}
