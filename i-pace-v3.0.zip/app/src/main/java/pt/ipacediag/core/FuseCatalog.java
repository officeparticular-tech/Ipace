package pt.ipacediag.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Caixas de fusíveis do Jaguar I-PACE (dados 2018-2020, compilados do manual do
 * proprietário Jaguar). Para cada fusível: número, amperagem e o circuito que
 * protege; o sintoma "se queimado" é derivado do circuito (ver {@link #symptom}).
 *
 * A caixa de ALTA TENSÃO (C) é apenas descritiva, com avisos — nunca se mexe.
 * Conteúdo de referência; os mapas variam por ano-modelo e mercado, por isso a
 * app recomenda confirmar sempre na etiqueta da tampa. Pura Java.
 */
public final class FuseCatalog {
    private FuseCatalog() {}

    public static final class Fuse {
        public final String num, amps, circuit, note; // note (sintoma específico) pode ser null
        public Fuse(String num, String amps, String circuit, String note) {
            this.num = num; this.amps = amps; this.circuit = circuit; this.note = note;
        }
    }

    public static final class Box {
        public final String id, name, location;
        public final boolean serviceable;
        public final String description, warning; // preenchidos na caixa de alta tensão
        public final List<Fuse> fuses;
        Box(String id, String name, String location, boolean serviceable, String description, String warning, List<Fuse> fuses) {
            this.id = id; this.name = name; this.location = location; this.serviceable = serviceable;
            this.description = description; this.warning = warning; this.fuses = fuses;
        }
    }

    /** Sintoma "se queimado" para um fusível (usa a nota específica ou deriva do circuito). */
    public static String symptom(Fuse f) {
        if (f.note != null) return f.note;
        return "Se queimado: " + f.circuit + " deixa de funcionar.";
    }

    private static Fuse f(String n, String a, String c) { return new Fuse(n, a, c, null); }
    private static Fuse f(String n, String a, String c, String note) { return new Fuse(n, a, c, note); }

    private static final List<Box> BOXES = new ArrayList<>();

    private static void box(String id, String name, String loc, Fuse... fuses) {
        BOXES.add(new Box(id, name, loc, true, null, null, new ArrayList<>(Arrays.asList(fuses))));
    }

    static {
        box("hab", "Caixa do habitáculo", "Debaixo do banco traseiro — levantar a almofada pela frente (não por trás, onde há cablagem).",
                f("1", "5A", "Sirene do alarme"),
                f("2", "5A", "Sistema de travões", "Se queimado: pode afetar o sistema de travões — SEGURANÇA. Não circule; procure uma oficina."),
                f("3", "5A", "Imobilizador", "Se queimado: o imobilizador pode impedir o arranque."),
                f("4", "5A", "Porta de diagnóstico (OBD)", "Se queimado: a tomada OBD fica sem alimentação e a app não comunica."),
                f("5", "5A", "Rádio e sensor de movimento"),
                f("6", "20A", "Tomada 12V (2ª fila)"),
                f("7", "20A", "Tomada 12V (consola central)"),
                f("8", "20A", "Banco frente esquerdo (circuito 2)"),
                f("9", "20A", "Banco frente direito (circuito 2)"),
                f("10", "30A", "Banco frente esquerdo (circuito 1)"),
                f("11", "30A", "Banco frente direito (circuito 1)"),
                f("12", "5A", "Espelhos elétricos"),
                f("13", "20A", "Tomada 12V (bagageira)"),
                f("14", "5A", "Câmara frontal"),
                f("16", "10A", "Quadrante de instrumentos"),
                f("17", "20A", "Desembaciador do óculo traseiro"),
                f("19", "5A", "Telemática (InControl)"),
                f("20", "20A", "Bancos aquecidos/climatizados"),
                f("21", "20A", "Bancos aquecidos/climatizados"),
                f("22", "25A", "Módulo da porta frente direita"),
                f("23", "25A", "Módulo da porta traseira esquerda"),
                f("24", "25A", "Módulo da porta traseira direita"),
                f("25", "25A", "Módulo da porta frente esquerda"),
                f("26", "10A", "Head-up display (HUD)"),
                f("27", "5A", "Módulo do telefone"),
                f("28", "5A", "Deteção de saída/porta"),
                f("29", "5A", "Controlador USB"),
                f("31", "5A", "Leitor de portagem"),
                f("32", "5A", "Pressão dos pneus (TPMS)"),
                f("33", "5A", "Comandos do volante"),
                f("34", "10A", "Portas USB"),
                f("35", "15A", "Regulação elétrica dos bancos"));

        box("f1", "Caixa dianteira nº 1", "Debaixo do capô, sob a tampa (soltar os fechos de rosca).",
                f("1", "5A", "Porta de carregamento"),
                f("2", "5A", "Câmara"),
                f("3", "5A", "Ar condicionado"),
                f("4", "5A", "Cruise control adaptativo"),
                f("6", "15A", "Controlador do porta-bagagens dianteiro (frunk)"),
                f("7", "30A", "Bomba lava-faróis"),
                f("8", "30A", "Lava para-brisas"),
                f("9", "15A", "Buzina"),
                f("10", "20A", "Esguichos aquecidos"),
                f("11", "5A", "Módulo do líquido de arrefecimento"),
                f("12", "10A", "Carregador de bordo (OBC)"),
                f("14", "15A", "Arrefecimento do sistema elétrico"),
                f("15", "15A", "Arrefecimento da bateria"),
                f("16", "15A", "Arrefecimento do sistema elétrico"),
                f("17", "5A", "Gestão de energia elétrica"),
                f("18", "5A", "Gestão de energia elétrica"),
                f("38", "15A", "Bloqueio de estacionamento (park lock)", "Se queimado: o bloqueio de estacionamento pode falhar — SEGURANÇA (o carro pode não ficar imobilizado). Procure uma oficina."),
                f("39", "5A", "Travões", "Se queimado: pode afetar o sistema de travões — SEGURANÇA. Não circule; procure uma oficina."));

        box("f2", "Caixa dianteira nº 2", "Debaixo do capô, mesma zona da caixa nº 1.",
                f("19", "5A", "Sistema de arrefecimento"),
                f("20", "5A", "Grelhas ativas (active vanes)"),
                f("22", "10A", "Gestão de energia"),
                f("23", "10A", "Faróis de nevoeiro dianteiros"),
                f("27", "20A", "Farol (unidade)"),
                f("28", "20A", "Farol (unidade)"),
                f("29", "5A", "Gestão de energia"),
                f("30", "5A", "Gestão de energia"),
                f("31", "10A", "Gestão de energia"),
                f("32", "5A", "Gestão de energia"),
                f("33", "5A", "Gestão de energia"),
                f("34", "5A", "Gestão de energia"),
                f("35", "5A", "Sistema de arrefecimento"));

        box("bag", "Caixa da bagageira", "Atrás do painel de revestimento da bagageira — a etiqueta no verso mostra os circuitos.",
                f("1", "20A", "Banco traseiro aquecido esquerdo"),
                f("2", "20A", "Banco traseiro aquecido direito"),
                f("3", "5A", "Consola do switch pack traseiro"),
                f("4", "10A", "Módulo de controlo do chassis"),
                f("5", "15A", "Módulo de controlo do chassis"),
                f("10", "20A", "Isqueiro / tomada (ACC)"),
                f("16", "5A", "Controlo do chassis"),
                f("17", "30A", "Módulo da mala elétrica (tailgate)"),
                f("18", "5A", "Antena da mala"),
                f("19", "5A", "Switch pack"),
                f("20", "5A", "PAM (assistência ao estacionamento)"));

        // Caixa C — ALTA TENSÃO (apenas descritiva, nunca se mexe)
        BOXES.add(new Box("hv", "Caixa C — alta tensão", "Debaixo do capô (zona de alta tensão).", false,
                "Caixa de fusíveis de ALTA TENSÃO, ligada à High Voltage Junction Box (HVJB). Protege os componentes auxiliares de alta tensão: o conversor DC/DC, o aquecedor interior de alta tensão e o compressor elétrico do ar condicionado. A Battery Energy Module tem ainda um fusível auxiliar; um curto-circuito nestes componentes queima fusíveis na HVJB e regista no BECM o erro P0A95-00 (\"High Voltage Fuse A\").",
                "NÃO ABRIR — PERIGO DE MORTE. Sistema de alta tensão (~400 V). É selada de fábrica e, segundo o manual Jaguar, só acessível por oficina/reparador autorizado, com formação EV, equipamento de proteção e luvas isolantes, e apenas depois de o sistema de alta tensão ser corretamente desligado. Para o erro P0A95, a Jaguar indica NÃO tentar substituir peças nem fazer diagnósticos prolongados — contactar assistência técnica autorizada.",
                new ArrayList<>()));
    }

    public static List<Box> all() { return BOXES; }
}
