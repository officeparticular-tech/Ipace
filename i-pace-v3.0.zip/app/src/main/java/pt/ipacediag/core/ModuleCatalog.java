package pt.ipacediag.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Base de conhecimento dos módulos do I-Pace: o que cada um faz e os tipos de
 * falha que costuma gerar. Serve o ecrã "Módulos" e enriquece o relatório.
 * Conteúdo de referência (offline), redigido a nível funcional — as descrições
 * de DTC específicas da JLR nem sempre são públicas, por isso as "falhas
 * típicas" são famílias/sintomas, não um catálogo exaustivo de códigos.
 * Para os módulos sem ficha específica, gera-se uma descrição genérica a partir
 * do nome. Pura Java.
 */
public final class ModuleCatalog {
    private ModuleCatalog() {}

    public static final class Detail {
        public final String description;
        public final List<String> faults;
        public Detail(String description, List<String> faults) { this.description = description; this.faults = faults; }
    }

    private static final Map<Integer, Detail> BY_TX = new HashMap<>();

    private static void put(int tx, String desc, String... faults) {
        BY_TX.put(tx, new Detail(desc, new ArrayList<>(Arrays.asList(faults))));
    }

    static {
        put(IpaceModules.BECM,
                "Cérebro da bateria de alta tensão (90 kWh): mede tensão, corrente, temperatura e o estado de carga/saúde de cada módulo de células, comanda os contactores e vigia a proteção de isolamento. É o módulo-chave para a garantia da bateria.",
                "Falha de isolamento / alta tensão (família P0AA6 — HVIL) — segurança: documentar, não apagar",
                "Sobreaquecimento ou arrefecimento insuficiente do pack",
                "Desequilíbrio ou célula fraca",
                "Erros de contactor",
                "Tensão 12V baixa (U3003) e perda de comunicação (U0…)");
        put(IpaceModules.BCCM,
                "Controla o carregador de bordo (corrente alternada) e a negociação com o posto de carregamento.",
                "Falhas de carregamento AC", "Negociação com o posto/cabo", "Sobreaquecimento do carregador", "Comunicação");
        put(IpaceModules.DCDC,
                "Converte a alta tensão para 12V (faz o papel do alternador): mantém a bateria de 12V carregada com o carro ligado.",
                "Não carrega a 12V (a 12V vai descarregando)", "Sobretensão/subtensão na linha de 12V", "Sobreaquecimento");
        put(IpaceModules.BCM,
                "Módulo de controlo da carroçaria: luzes, limpa-vidros, fecho central, alarme e funções de conforto.",
                "Atuadores (luzes, limpa, fecho)", "Sensores de carroçaria", "Perda de comunicação (U0…)", "Alimentação/12V");
        put(IpaceModules.GWM,
                "Gateway central: encaminha as mensagens entre os vários barramentos CAN e é a porta de entrada do diagnóstico (OBD/DoIP).",
                "Perda de comunicação com módulos (U0…)", "Gestão de rede", "Questões de atualização de software");
        put(IpaceModules.EPICB,
                "Inversor e controlo do motor elétrico dianteiro.",
                "Sobreaquecimento do inversor/motor", "Sensores de posição/corrente", "Redução de potência (derating)", "Isolamento");
        put(IpaceModules.EPICC,
                "Inversor e controlo do motor elétrico traseiro.",
                "Sobreaquecimento do inversor/motor", "Sensores de posição/corrente", "Redução de potência (derating)", "Isolamento");
        put(IpaceModules.BBM,
                "Servofreio elétrico (booster da travagem).",
                "Perda de assistência de travagem", "Sensores de pressão/curso", "Comunicação com o ABS");
        put(0x7E6,
                "Travagem ABS/ESP e coordenação da travagem regenerativa.",
                "Sensores de roda", "Válvulas do grupo hidráulico", "Estabilidade (ESP)", "Coordenação da regeneração");
        put(0x730,
                "Direção assistida elétrica (EPAS).",
                "Motor/sensor de binário", "Perda de assistência", "Sobreaquecimento");
        put(0x737,
                "Airbags e pré-tensores (sistema de retenção).",
                "Circuitos de airbag/pré-tensor — SEGURANÇA: não apagar sem reparar", "Sensores de impacto", "Luz de airbag acesa");
        put(0x720,
                "Quadrante de instrumentos (mostrador ao condutor).",
                "Indicadores/avisos", "Iluminação do painel", "Comunicação");
        put(IpaceModules.HVAC,
                "Climatização do habitáculo; partilha circuitos com o arrefecimento/aquecimento da bateria (bomba de calor).",
                "Compressor / bomba de calor", "Sensores de temperatura", "Atuadores de distribuição de ar");
        put(IpaceModules.TPMS,
                "Monitorização da pressão dos pneus.",
                "Sensor de pressão", "Aprendizagem das posições", "Bateria do sensor no fim de vida");
        put(IpaceModules.TCU,
                "Telemática / InControl: ligação móvel, GPS, chamada de emergência e dados.",
                "Modem/SIM ou GPS", "Comunicação", "Consumo que descarrega a 12V (relato comum na comunidade)");
    }

    public static Detail forModule(IpaceModules.Module m) {
        Detail d = BY_TX.get(m.tx);
        return d != null ? d : generic(m);
    }

    public static Detail forTx(int tx) {
        Detail d = BY_TX.get(tx);
        if (d != null) return d;
        for (IpaceModules.Module m : IpaceModules.all()) if (m.tx == tx) return generic(m);
        return new Detail("Módulo do veículo.", genericFaults());
    }

    private static Detail generic(IpaceModules.Module m) {
        return new Detail(m.name + ".", genericFaults());
    }

    /** Localização física aproximada do módulo no carro (ou null se não documentada). */
    public static String location(int tx) {
        switch (tx) {
            case IpaceModules.BECM: return "Dentro do pack de alta tensão, sob o piso do carro (entre os eixos).";
            case IpaceModules.BCCM: return "Zona dianteira, junto ao carregador de bordo.";
            case IpaceModules.DCDC: return "Zona dianteira (compartimento do motor dianteiro).";
            case IpaceModules.BCM:  return "Atrás do tablier, do lado do passageiro.";
            case IpaceModules.GWM:  return "Central, atrás da consola/tablier.";
            case IpaceModules.EPICB: return "No eixo dianteiro, junto ao motor elétrico dianteiro.";
            case IpaceModules.EPICC: return "No eixo traseiro, junto ao motor elétrico traseiro.";
            case IpaceModules.BBM:  return "Vão dianteiro, na zona da pedaleira (servofreio).";
            case 0x7E6:             return "Vão dianteiro, no grupo hidráulico de travagem (ABS).";
            case 0x730:             return "Na direção assistida (cremalheira/coluna).";
            case 0x737:             return "Consola central, sob o túnel.";
            case 0x720:             return "No tablier (quadrante de instrumentos).";
            case IpaceModules.HVAC: return "Consola central, atrás do tablier.";
            case IpaceModules.TPMS: return "Habitáculo, atrás do tablier.";
            case IpaceModules.TCU:  return "Zona traseira do carro (perto das antenas).";
            case 0x740:             return "Na porta do condutor.";
            case 0x741:             return "Na porta do passageiro.";
            case 0x742:             return "Na porta traseira esquerda.";
            case 0x743:             return "Na porta traseira direita.";
            default: return null;
        }
    }

    private static List<String> genericFaults() {
        return new ArrayList<>(Arrays.asList(
                "Falhas internas do módulo",
                "Sensores/atuadores associados",
                "Perda de comunicação (U0…)",
                "Alimentação / 12V baixa (U3003)"));
    }
}
