package pt.ipacediag.core;

import java.io.IOException;
import java.util.Locale;

/**
 * Leitura da bateria do Nissan Leaf (2013–2017, AZE0) ao estilo do LeafSpy.
 *
 * O controlador da bateria (LBC) responde à tomada OBD por CAN 11 bits 500k:
 * pergunta-se a 0x79B e lê-se a resposta em 0x7BB, com o serviço 0x21 por grupos.
 * A remontagem das várias tramas (ISO-TP) é feita pelo ElmSession.
 *
 * Posições e fórmulas segundo a engenharia inversa da comunidade (TickTock e outros,
 * fórum mynissanleaf.com — "Data from the Leaf Battery App"). São achados da
 * comunidade, não uma especificação oficial, mas estão bem estabelecidos:
 *   Grupo 1 (21 01): SOH, SOC preciso, capacidade (Ah)
 *   Grupo 2 (21 02): as 96 tensões de célula (16 bits, mV)
 *   Grupo 4 (21 04): 4 temperaturas do pack (byte de grau direto)
 * A tensão do pack é a soma das 96 células.
 *
 * NOTA: com o carro desligado e a carregar, pedir estes grupos pode fazer "clicar"
 * relés; não convém amostrar mais do que de poucos em poucos minutos nesse estado.
 */
public final class LeafBattery {

    public static final int LBC_TX = 0x79B, LBC_RX = 0x7BB;

    public boolean ok;
    public String error = "";
    public double packV = Double.NaN, packA = Double.NaN;   // packA não é lido por este método
    public double soh = Double.NaN, hx = Double.NaN, ahr = Double.NaN, soc = Double.NaN; // hx não documentado
    public double tMin = Double.NaN, tMax = Double.NaN;
    public int cellCount;
    public final double[] cells = new double[96];
    public byte[] rawGroup1, rawGroup2, rawGroup4;

    /** Lê um grupo (serviço 0x21 + nº do grupo). Devolve o payload completo (61 0g …) ou null. */
    public static byte[] group(ElmSession s, int g) throws IOException {
        UdsResponse r = s.requestEx(LBC_TX, LBC_RX, new byte[]{0x21, (byte) g}, 3);
        return r.ok() ? r.payload : null;
    }

    public LeafBattery read(ElmSession s) throws IOException {
        rawGroup1 = group(s, 0x01);
        rawGroup2 = group(s, 0x02);
        rawGroup4 = group(s, 0x04);
        if (rawGroup1 == null && rawGroup2 == null) {
            error = "O controlador da bateria (LBC) não respondeu. Confirme que o carro está ligado (contacto).";
            return this;
        }
        decodeGroup1(rawGroup1);
        decodeCells(rawGroup2);
        decodeTemps(rawGroup4);
        if (cellCount > 0) {
            double sum = 0;
            for (int i = 0; i < cellCount; i++) sum += cells[i];
            packV = sum;                                   // tensão do pack = soma das células
        }
        ok = true;
        return this;
    }

    // --- descodificação (offsets no payload já remontado: payload[0]=0x61, [1]=nº do grupo) ---

    private void decodeGroup1(byte[] p) {
        if (p == null || p.length < 38) return;
        soh = Hex.u16(p, 27) / 100.0;                      // 0x25A4 -> 96.36 %
        soc = Hex.u24(p, 31) / 10000.0;                    // 0x0C2DFA -> 79.8202 %
        ahr = Hex.u24(p, 35) / 10000.0;                    // 0x0A4754 -> 67.3620 Ah
    }

    private void decodeCells(byte[] p) {
        if (p == null || p.length < 4) return;
        int n = 0;
        for (int i = 0; i < 96 && 2 + i * 2 + 1 < p.length; i++) {
            cells[i] = Hex.u16(p, 2 + i * 2) / 1000.0;     // 16 bits big-endian, mV -> V
            n++;
        }
        cellCount = n;
    }

    private void decodeTemps(byte[] p) {
        if (p == null || p.length < 14) return;
        int[] idx = {4, 7, 10, 13};                        // byte de grau de cada uma das 4 sondas
        double mn = Double.MAX_VALUE, mx = -Double.MAX_VALUE;
        int c = 0;
        for (int k : idx) {
            if (k < p.length) {
                double t = (byte) p[k];                    // grau inteiro, com sinal
                mn = Math.min(mn, t);
                mx = Math.max(mx, t);
                c++;
            }
        }
        if (c > 0) { tMin = mn; tMax = mx; }
    }

    public double cellMin() { double m = Double.MAX_VALUE; for (int i = 0; i < cellCount; i++) m = Math.min(m, cells[i]); return cellCount == 0 ? Double.NaN : m; }
    public double cellMax() { double m = -1; for (int i = 0; i < cellCount; i++) m = Math.max(m, cells[i]); return cellCount == 0 ? Double.NaN : m; }
    public double cellAvg() { double s = 0; for (int i = 0; i < cellCount; i++) s += cells[i]; return cellCount == 0 ? Double.NaN : s / cellCount; }
    public double cellDeltaMv() { return cellCount == 0 ? Double.NaN : (cellMax() - cellMin()) * 1000.0; }

    public String sohVerdict() {
        if (Double.isNaN(soh)) return "";
        if (soh >= 85) return "BOM";
        if (soh >= 75) return "ACEITÁVEL";
        if (soh >= 65) return "FRACO — perto de perder barra de capacidade";
        return "MAU";
    }

    public static String f(double v, int dec, String unit) {
        return Double.isNaN(v) ? "—" : String.format(Locale.US, "%." + dec + "f", v) + (unit.isEmpty() ? "" : " " + unit);
    }
}
