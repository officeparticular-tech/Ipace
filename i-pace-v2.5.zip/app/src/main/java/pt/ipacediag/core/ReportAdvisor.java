package pt.ipacediag.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Conclusões do relatório: cruza TODOS os erros de todos os módulos e devolve
 * uma lista de sugestões finais ordenadas por prioridade. A ideia é que o
 * utilizador veja logo "por onde começar" — por exemplo, se vários módulos
 * acusam tensão 12V anormal, essa ação aparece em primeiro lugar, porque uma
 * 12V fraca provoca em cascata muitos outros erros.
 *
 * Prioridade = severidade da família × 4 + nº de ocorrências × 3. Assim a
 * gravidade pesa, mas um problema que aparece em muitos módulos sobe na lista
 * (ex.: 12V anormal em vários módulos passa à frente de um isolamento isolado).
 * Pura Java.
 */
public final class ReportAdvisor {
    private ReportAdvisor() {}

    public static final class Suggestion {
        public final String title, text;
        public final int score, count;
        public final boolean safety;
        public Suggestion(String title, String text, int score, int count, boolean safety) {
            this.title = title; this.text = text; this.score = score; this.count = count; this.safety = safety;
        }
    }

    public static List<Suggestion> analyze(List<Diagnostics.ModuleInfo> mods) {
        int lowV = 0;                       // U3003 (12V anormal)
        int isolation = 0;                  // P0AA*/P0A9*/P1B4* — isolamento/alta tensão
        int hvOther = 0;                    // outros erros do BECM/BCCM
        int comms = 0;                      // U0* — perda de comunicação
        int other = 0;                      // o resto
        Set<String> lowVMods = new LinkedHashSet<>();
        Set<String> isoMods = new LinkedHashSet<>();
        Set<String> commsMods = new LinkedHashSet<>();
        int totalErr = 0, modsWithErr = 0;

        if (mods != null) for (Diagnostics.ModuleInfo mi : mods) {
            if (!mi.responded || mi.dtcs.isEmpty()) continue;
            modsWithErr++;
            for (Dtc d : mi.dtcs) {
                totalErr++;
                String b = d.base();
                if (DtcCatalog.isLowVoltageEvent(d)) { lowV++; lowVMods.add(mi.module.code); }
                else if (b.startsWith("P0AA") || b.startsWith("P0A9") || b.startsWith("P1B4")) { isolation++; isoMods.add(mi.module.code); }
                else if (DtcCatalog.isHighVoltage(d)) { hvOther++; }
                else if (b.startsWith("U0")) { comms++; commsMods.add(mi.module.code); }
                else { other++; }
            }
        }

        List<Suggestion> out = new ArrayList<>();
        if (totalErr == 0) return out;

        if (lowV > 0) {
            boolean many = lowV >= 2;
            String t = (many ? lowV + " módulos registaram" : "Um módulo registou") + " tensão 12V anormal (U3003"
                    + (lowVMods.isEmpty() ? "" : " em " + join(lowVMods)) + "). "
                    + "É o sintoma clássico de bateria de 12V fraca ou em fim de vida — e, quando está fraca, provoca em cascata muitos outros erros e perdas de comunicação. "
                    + "Comece por aqui: teste ou substitua a bateria de 12V, volte a ler os erros e é provável que vários desapareçam sozinhos.";
            out.add(new Suggestion("Começar pela bateria de 12V", t, 5 * 4 + lowV * 3, lowV, false));
        }
        if (isolation > 0) {
            String t = "Há " + isolation + " erro(s) de isolamento / alta tensão (família P0AA/P0A9/P1B4"
                    + (isoMods.isEmpty() ? "" : ", em " + join(isoMods)) + "). "
                    + "É uma questão de SEGURANÇA e de garantia: NÃO apague estes erros — são a prova do problema. "
                    + "Guarde este relatório e leve o carro à marca; se a bateria de alta tensão estiver em causa, pode enquadrar-se num recall (ex.: H572).";
            out.add(new Suggestion("Isolamento / alta tensão — não apagar, documentar", t, 6 * 4 + isolation * 3, isolation, true));
        }
        if (hvOther > 0) {
            String t = hvOther + " erro(s) no sistema de alta tensão (BECM/BCCM) fora da família de isolamento. "
                    + "Vale a pena guardar os dados do momento (condições guardadas) e vigiar a saúde da bateria ao longo do tempo antes de tirar conclusões.";
            out.add(new Suggestion("Vigiar o sistema de alta tensão", t, 4 * 4 + hvOther * 3, hvOther, false));
        }
        if (comms > 0) {
            String t = comms + " erro(s) de comunicação entre módulos (U0" + (commsMods.isEmpty() ? "" : ", em " + join(commsMods)) + "). "
                    + (lowV > 0
                        ? "Como também há sinais de 12V fraca, é muito provável que sejam secundários: resolva primeiro a 12V e volte a ler."
                        : "Confirme se algum módulo está sem alimentação ou desligado; se persistirem após verificar a 12V e as ligações, podem indicar um módulo ou cablagem com problema.");
            out.add(new Suggestion("Comunicação entre módulos", t, 3 * 4 + comms * 3, comms, false));
        }
        if (other > 0) {
            out.add(new Suggestion("Outros erros", other + " outro(s) erro(s) sem padrão comum. Veja a descrição e as origens/soluções de cada um na lista acima.", 2 * 4 + other * 3, other, false));
        }

        // Ordenar por prioridade (score desc); empate → segurança primeiro, depois mais ocorrências
        Collections.sort(out, (a, b) -> {
            if (a.score != b.score) return b.score - a.score;
            if (a.safety != b.safety) return a.safety ? -1 : 1;
            return b.count - a.count;
        });
        return out;
    }

    private static String join(Set<String> s) {
        StringBuilder sb = new StringBuilder();
        for (String x : s) { if (sb.length() > 0) sb.append(", "); sb.append(x); }
        return sb.toString();
    }
}
