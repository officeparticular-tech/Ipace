package pt.ipacediag.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Histórico da saúde da bateria ao longo do tempo: guarda cada leitura (data, carro,
 * SOH e capacidade) para mostrar a degradação num gráfico. Pura lógica (sem Android):
 * a UI dá-lhe o texto guardado e recebe de volta o texto a gravar.
 *
 * Formato de gravação: uma linha por amostra, campos separados por '|':
 *   time|car|soh|capacity|odo
 * (valores em falta ficam vazios). Simples e robusto de ler/escrever.
 */
public final class HealthHistory {

    public static final class Sample {
        public final long time;      // epoch ms
        public final String car;     // "ipace" | "leaf"
        public final double soh;     // %
        public final double capacity;// Ah (Leaf) ou % cap (I-Pace já vem em soh); NaN se não há
        public final double odo;     // km, NaN se desconhecido

        public Sample(long time, String car, double soh, double capacity, double odo) {
            this.time = time; this.car = car == null ? "" : car;
            this.soh = soh; this.capacity = capacity; this.odo = odo;
        }
    }

    private final List<Sample> samples = new ArrayList<>();

    public void add(Sample s) { if (s != null) samples.add(s); }
    public List<Sample> all() { return samples; }
    public int size() { return samples.size(); }

    /** Remove todos os registos de um carro. Devolve quantos foram removidos. */
    public int clearCar(String car) {
        int n = 0;
        for (int i = samples.size() - 1; i >= 0; i--) {
            if (samples.get(i).car.equals(car)) { samples.remove(i); n++; }
        }
        return n;
    }

    public List<Sample> forCar(String car) {
        List<Sample> out = new ArrayList<>();
        for (Sample s : samples) if (s.car.equals(car)) out.add(s);
        return out;
    }

    /** Resumo da degradação para um carro: primeira vs última leitura de SOH. */
    public String summary(String car) {
        List<Sample> l = forCar(car);
        if (l.isEmpty()) return "Sem leituras guardadas.";
        if (l.size() == 1) return "1 leitura guardada. Guarde mais ao longo do tempo para ver a tendência.";
        Sample first = l.get(0), last = l.get(l.size() - 1);
        double dSoh = last.soh - first.soh;
        double days = (last.time - first.time) / 86_400_000.0;
        String rate = "";
        if (days >= 30 && !Double.isNaN(dSoh)) {
            double perYear = dSoh / days * 365.0;
            rate = String.format(Locale.US, " (~%.1f pp/ano)", perYear);
        }
        return String.format(Locale.US, "SOH: %.1f%% → %.1f%% (%+.1f pp em %.0f dias)%s · %d leituras",
                first.soh, last.soh, dSoh, days, rate, l.size());
    }

    public String toText() {
        StringBuilder sb = new StringBuilder();
        for (Sample s : samples) {
            sb.append(s.time).append('|').append(s.car).append('|')
              .append(num(s.soh)).append('|').append(num(s.capacity)).append('|').append(num(s.odo)).append('\n');
        }
        return sb.toString();
    }

    public static HealthHistory fromText(String text) {
        HealthHistory h = new HealthHistory();
        if (text == null) return h;
        for (String line : text.split("\n")) {
            line = line.trim();
            if (line.isEmpty()) continue;
            String[] p = line.split("\\|", -1);
            if (p.length < 5) continue;
            try {
                h.add(new Sample(Long.parseLong(p[0]), p[1], parse(p[2]), parse(p[3]), parse(p[4])));
            } catch (NumberFormatException ignored) { }
        }
        return h;
    }

    private static String num(double v) { return Double.isNaN(v) ? "" : String.format(Locale.US, "%.3f", v); }
    private static double parse(String s) { return s == null || s.isEmpty() ? Double.NaN : Double.parseDouble(s); }
}
