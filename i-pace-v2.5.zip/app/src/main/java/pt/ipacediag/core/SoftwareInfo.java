package pt.ipacediag.core;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Lê as versões de software/hardware e os números de peça de um módulo, pelos
 * identificadores normalizados (serviço 0x22). Útil para confirmar, por exemplo,
 * se a atualização de software do BECM (ação H441) já está aplicada — comparando
 * a versão lida com a que a oficina indicar.
 *
 * Só leitura. Os valores vêm em texto (ASCII) no próprio módulo.
 */
public final class SoftwareInfo {
    private SoftwareInfo() {}

    public static final class Entry {
        public final String label, value;
        public Entry(String label, String value) { this.label = label; this.value = value; }
    }

    private static final int[] DIDS = {0xF188, 0xF189, 0xF191, 0xF194, 0xF195, 0xF187, 0xF18C};
    private static final String[] LABELS = {
            "Software (fabricante)", "Versão de software", "Hardware",
            "Software (fornecedor)", "Versão (fornecedor)", "Nº de peça", "Nº de série"};

    public static List<Entry> read(ElmSession s, int tx) throws IOException {
        List<Entry> out = new ArrayList<>();
        for (int i = 0; i < DIDS.length; i++) {
            byte[] d;
            try { d = s.readDid(tx, DIDS[i]); } catch (IOException e) { throw e; } catch (Exception e) { d = null; }
            if (d == null || d.length == 0) continue;
            String v = ascii(d);
            if (v.length() > 0) out.add(new Entry(LABELS[i], v));
        }
        return out;
    }

    static String ascii(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) {
            int c = x & 0xFF;
            if (c >= 32 && c < 127) sb.append((char) c);
            else if (c != 0) sb.append('.');
        }
        return sb.toString().trim();
    }
}
