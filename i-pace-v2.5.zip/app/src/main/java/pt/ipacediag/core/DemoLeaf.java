package pt.ipacediag.core;

import java.util.Random;

/**
 * Nissan Leaf SIMULADO para o modo demonstração.
 * Responde como um ELM327 ligado ao LBC: pergunta a 0x79B, responde em 0x7BB, serviço
 * 0x21 por grupos, com o mesmo layout que o LeafBattery descodifica (achados da
 * comunidade mynissanleaf.com). Valores fictícios mas plausíveis para um Leaf de 2015
 * com alguma degradação: SOH ~86,4%, AHr ~56,1, SOC ~73,5%, células ~3,9 V.
 */
public final class DemoLeaf implements ObdTransport {

    private int tx = 0x7DF, rx = 0x7E8;
    private boolean open = true;
    private final Random rnd = new Random(11);

    public boolean isOpen() { return open; }
    public void close() { open = false; }

    private static byte[] cat(int... parts) {
        byte[] b = new byte[parts.length];
        for (int i = 0; i < parts.length; i++) b[i] = (byte) parts[i];
        return b;
    }

    private String frames(byte[] p) {
        if (p.length <= 7) return Hex.h3(rx) + " " + Hex.h2(p.length) + " " + Hex.of(p);
        StringBuilder sb = new StringBuilder();
        sb.append(Hex.h3(rx)).append(" 1").append(Integer.toHexString((p.length >> 8) & 0xF).toUpperCase())
                .append(' ').append(Hex.h2(p.length)).append(' ').append(Hex.of(p, 0, 6)).append('\r');
        int idx = 6, seq = 1;
        while (idx < p.length) {
            int end = Math.min(p.length, idx + 7);
            sb.append(Hex.h3(rx)).append(" 2").append(Integer.toHexString(seq & 0xF).toUpperCase()).append(' ').append(Hex.of(p, idx, end));
            for (int k = end - idx; k < 7; k++) sb.append(" AA");
            sb.append('\r');
            idx = end; seq++;
        }
        return sb.toString();
    }

    private static void put16(byte[] p, int i, int v) { p[i] = (byte) (v >> 8); p[i + 1] = (byte) v; }
    private static void put24(byte[] p, int i, int v) { p[i] = (byte) (v >> 16); p[i + 1] = (byte) (v >> 8); p[i + 2] = (byte) v; }

    private byte[] group1() {
        // 61 01 + SOH (27-28), SOC preciso (31-33), Ah (35-37)
        byte[] p = new byte[38];
        p[0] = 0x61; p[1] = 0x01;
        put16(p, 27, 8640);     // SOH 86.40 %
        put24(p, 31, 735000);   // SOC 73.5000 %
        put24(p, 35, 561200);   // AHr 56.1200
        return p;
    }

    private byte[] group2() {
        // 61 02 + 96 células de 16 bits (mV), a rondar 3,9 V com pequena dispersão
        byte[] p = new byte[2 + 96 * 2];
        p[0] = 0x61; p[1] = 0x02;
        for (int i = 0; i < 96; i++) put16(p, 2 + i * 2, 3900 + rnd.nextInt(24) - 12);
        return p;
    }

    private byte[] group4() {
        // 61 04 + 4 sondas: [A/D hi, A/D lo, grau]  -> graus ~20..22
        byte[] p = new byte[14];
        p[0] = 0x61; p[1] = 0x04;
        int[] deg = {21, 21, 20, 22};
        int[] at = {4, 7, 10, 13};
        for (int k = 0; k < 4; k++) { p[at[k] - 2] = 0x01; p[at[k] - 1] = (byte) 0xF8; p[at[k]] = (byte) deg[k]; }
        return p;
    }

    @Override
    public synchronized String command(String c, long timeoutMs) {
        try { Thread.sleep(12 + rnd.nextInt(16)); } catch (InterruptedException ignored) { }
        if (c.equals("ATZ")) return "ELM327 v1.5";
        if (c.equals("STI")) return "Simulador Leaf (modo demonstração)";
        if (c.equals("ATRV")) return "12.5V";
        if (c.startsWith("ATSH")) { tx = Integer.parseInt(c.substring(4), 16); return "OK"; }
        if (c.startsWith("ATCRA")) { rx = Integer.parseInt(c.substring(5), 16); return "OK"; }
        if (c.startsWith("AT")) return "OK";
        byte[] req;
        try { req = Hex.parse(c); } catch (Exception e) { return "?"; }
        if (tx == LeafBattery.LBC_TX && req.length >= 2 && (req[0] & 0xFF) == 0x21) {
            switch (req[1] & 0xFF) {
                case 0x01: return frames(group1());
                case 0x02: return frames(group2());
                case 0x04: return frames(group4());
                default: return frames(cat(0x7F, 0x21, 0x31));
            }
        }
        if (req.length >= 1 && (req[0] & 0xFF) == 0x3E) return frames(cat(0x7E, 0x00));
        return "NO DATA";
    }
}
