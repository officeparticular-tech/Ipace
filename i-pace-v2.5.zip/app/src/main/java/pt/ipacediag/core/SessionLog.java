package pt.ipacediag.core;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Registo técnico da sessão de diagnóstico. Guarda, com data/hora, tudo o que
 * passa na ligação (comandos ao adaptador e respostas em bruto, pedidos UDS e o
 * seu resultado, e eventos da app). Serve dois fins:
 *   1) exportar um ficheiro para análise posterior (perceber o que falhou);
 *   2) alimentar o autodiagnóstico ({@link LinkDoctor}).
 *
 * Mantém no máximo {@code max} entradas (as mais antigas são descartadas) e vai
 * contando sintomas para o diagnóstico não ter de reprocessar todo o texto.
 * Pura Java, sem dependências de Android. Thread-safe.
 */
public final class SessionLog {

    public static final class Entry {
        public final long t;
        public final String tag, text;
        Entry(long t, String tag, String text) { this.t = t; this.tag = tag; this.text = text; }
    }

    private final ArrayDeque<Entry> entries = new ArrayDeque<>();
    private final int max;

    // Contadores para o diagnóstico
    public int countTx, countPos, countNeg, countNone, countErr;
    public final LinkedHashMap<String, Integer> elmErrors = new LinkedHashMap<>();
    public final LinkedHashMap<Integer, Integer> nrcs = new LinkedHashMap<>();
    public double lastVoltage = Double.NaN;
    public String adapterId = "";
    public long started = System.currentTimeMillis();

    public SessionLog() { this(4000); }
    public SessionLog(int max) { this.max = Math.max(200, max); }

    private void add(String tag, String text) {
        entries.addLast(new Entry(System.currentTimeMillis(), tag, text));
        while (entries.size() > max) entries.removeFirst();
    }

    private static void bump(Map<String, Integer> m, String k) { m.put(k, m.getOrDefault(k, 0) + 1); }
    private static void bump(Map<Integer, Integer> m, int k) { m.put(k, m.getOrDefault(k, 0) + 1); }

    /** Evento de alto nível da app (ligação, scan, etc.). */
    public synchronized void event(String tag, String msg) { add(tag, msg); }

    /** Comando ao adaptador e resposta em bruto (nível ELM/AT). */
    public synchronized void traffic(String cmd, String resp) {
        countTx++;
        String r = resp == null ? "" : resp;
        add("AT", cmd + "  →  " + oneLine(r));
        String e = ElmParser.errorOf(r);
        if (e != null) bump(elmErrors, e);
    }

    /** Resultado estruturado de um pedido UDS (já classificado). */
    public synchronized void uds(int tx, byte[] req, UdsResponse r) {
        add("UDS", Hex.h3(tx) + " " + Hex.of(req) + "  →  " + r.describe());
        switch (r.kind) {
            case POSITIVE: countPos++; break;
            case NEGATIVE: countNeg++; bump(nrcs, r.nrc); break;
            case NO_RESPONSE: countNone++; break;
            case ADAPTER_ERROR: countErr++; if (r.error != null) bump(elmErrors, r.error); break;
        }
    }

    public synchronized void setVoltage(double v) {
        lastVoltage = v;
        if (!Double.isNaN(v)) add("12V", String.format(Locale.US, "Tensão na tomada OBD: %.1f V", v));
    }

    public synchronized void setAdapter(String id) {
        adapterId = id == null ? "" : id;
        add("ADAPTADOR", "Identificação: " + adapterId);
    }

    public synchronized int size() { return entries.size(); }

    public synchronized void clear() {
        entries.clear();
        countTx = countPos = countNeg = countNone = countErr = 0;
        elmErrors.clear();
        nrcs.clear();
        lastVoltage = Double.NaN;
        started = System.currentTimeMillis();
    }

    /** Últimas n entradas, da mais antiga para a mais recente. */
    public synchronized java.util.List<Entry> recent(int n) {
        java.util.List<Entry> all = new java.util.ArrayList<>(entries);
        int from = Math.max(0, all.size() - n);
        return all.subList(from, all.size());
    }

    /** Texto completo para exportar e enviar para análise. */
    public synchronized String toText() {
        SimpleDateFormat f = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US);
        SimpleDateFormat d = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
        StringBuilder sb = new StringBuilder();
        sb.append("REGISTO TÉCNICO — i-Pace Diag\n");
        sb.append("Início da sessão: ").append(d.format(new Date(started))).append('\n');
        if (!adapterId.isEmpty()) sb.append("Adaptador: ").append(adapterId).append('\n');
        if (!Double.isNaN(lastVoltage)) sb.append(String.format(Locale.US, "Última tensão OBD: %.1f V%n", lastVoltage));
        sb.append("Totais: ").append(countTx).append(" comandos · ")
          .append(countPos).append(" OK · ").append(countNeg).append(" recusados · ")
          .append(countNone).append(" sem resposta · ").append(countErr).append(" erros de adaptador\n");
        if (!elmErrors.isEmpty()) {
            sb.append("Erros do adaptador: ");
            for (Map.Entry<String, Integer> e : elmErrors.entrySet()) sb.append(e.getKey()).append("×").append(e.getValue()).append("  ");
            sb.append('\n');
        }
        if (!nrcs.isEmpty()) {
            sb.append("Respostas negativas (NRC): ");
            for (Map.Entry<Integer, Integer> e : nrcs.entrySet())
                sb.append("0x").append(Hex.h2(e.getKey())).append(" (").append(Nrc.text(e.getKey())).append(")×").append(e.getValue()).append("  ");
            sb.append('\n');
        }
        sb.append("\n--- registo cronológico ---\n");
        for (Entry e : entries)
            sb.append(f.format(new Date(e.t))).append("  [").append(e.tag).append("] ").append(e.text).append('\n');
        return sb.toString();
    }

    static String oneLine(String s) {
        return s.replace("\r", " ").replace("\n", " ").replaceAll("\\s+", " ").trim();
    }
}
