package pt.ipacediag.core;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * "Freeze-frame" / condições guardadas de um erro: pede ao módulo o registo de
 * instantâneo (serviço 0x19, subfunção 0x04) para um DTC e mostra o que estava a
 * acontecer no momento em que a falha foi registada.
 *
 * O formato exato do registo é específico do fabricante; por isso faz-se uma
 * descodificação pelo melhor esforço (procura identificadores conhecidos — km, SOC,
 * 12V) e mostra também os dados em bruto (hex) como prova. Só leitura.
 */
public final class Snapshot {
    public boolean ok;
    public String error = "";
    public byte[] raw = new byte[0];
    public final List<String> lines = new ArrayList<>();

    public static Snapshot read(ElmSession s, int tx, Dtc d) throws IOException {
        Snapshot f = new Snapshot();
        byte[] req = new byte[]{0x19, 0x04, (byte) d.b1, (byte) d.b2, (byte) d.ftb, (byte) 0xFF};
        UdsResponse r = s.request(tx, req, 2);
        if (!r.ok()) {
            f.error = "Sem condições guardadas para este erro (ou o módulo não as fornece).";
            return f;
        }
        f.raw = r.payload;
        f.ok = true;
        decode(f);
        return f;
    }

    private static void decode(Snapshot f) {
        byte[] p = f.raw;
        for (int i = 5; i + 1 < p.length; i++) {
            int did = ((p[i] & 0xFF) << 8) | (p[i + 1] & 0xFF);
            if (did == 0xDD01 && i + 4 < p.length) {
                long km = ((long) (p[i + 2] & 0xFF) << 16) | ((p[i + 3] & 0xFF) << 8) | (p[i + 4] & 0xFF);
                f.lines.add("Quilómetros: " + km + " km");
            } else if (did == 0x4910 && i + 3 < p.length) {
                double soc = (((p[i + 2] & 0xFF) << 8) | (p[i + 3] & 0xFF)) / 100.0;
                f.lines.add(String.format(Locale.US, "Estado de carga: %.1f%%", soc));
            } else if ((did == 0x4905 || did == 0x4906) && i + 2 < p.length) {
                double t = (p[i + 2] & 0xFF) / 2.0 - 40;
                f.lines.add(String.format(Locale.US, "Temperatura bateria: %.0f °C", t));
            } else if (did == 0xDD02 && i + 2 < p.length) {
                double v = (p[i + 2] & 0xFF) / 10.0;
                f.lines.add(String.format(Locale.US, "Tensão 12V: %.1f V", v));
            }
        }
        if (f.lines.isEmpty()) f.lines.add("Condições guardadas (dados em bruto — ver hex).");
    }

    public String hex() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < raw.length; i++) {
            sb.append(Hex.h2(raw[i] & 0xFF));
            sb.append((i + 1) % 12 == 0 ? '\n' : ' ');
        }
        return sb.toString().trim();
    }
}
