package pt.ipacediag.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Autodiagnóstico da ligação: olha para o {@link SessionLog} e explica, em
 * português simples, o que provavelmente falhou e o que experimentar a seguir.
 * Também traduz, de forma isolada, um erro do adaptador ou um código de resposta
 * negativa (NRC) para conselho prático. Pura Java, sem Android.
 */
public final class LinkDoctor {
    private LinkDoctor() {}

    public enum Level { OK, INFO, WARN, BAD }

    public static final class Finding {
        public final Level level;
        public final String title, advice;
        public Finding(Level level, String title, String advice) { this.level = level; this.title = title; this.advice = advice; }
    }

    /** Conselho para um erro do adaptador ELM (string de {@link ElmParser#errorOf}). */
    public static String explainError(String err) {
        if (err == null) return "";
        switch (err) {
            case "UNABLE TO CONNECT":
                return "O adaptador não conseguiu falar com a rede do carro. Normalmente é o carro a dormir: abra uma porta ou carregue no travão para o acordar e tente de novo. Confirme também que está em OBD-II CAN 11 bits 500k (ATSP6) e use um adaptador de qualidade.";
            case "NO DATA":
                return "O pedido saiu mas nenhum módulo respondeu naquele endereço. É normal para módulos que não existem; se TODOS derem NO DATA, o carro está a dormir ou o protocolo/endereço está errado.";
            case "CAN ERROR":
                return "Conflito no barramento CAN. Verifique o encaixe da ficha OBD, a bateria de 12V e o protocolo (ATSP6). Adaptadores fracos também causam isto.";
            case "BUS INIT":
            case "BUS ERROR":
                return "Falha ao iniciar o barramento. Acorde o carro, confirme o protocolo e volte a tentar; se persistir, troque de adaptador.";
            case "BUFFER FULL":
                return "A resposta foi grande demais para o adaptador. Convém ler por partes ou abrandar o ritmo (a app já faz isto na maioria dos casos).";
            case "STOPPED":
                return "O pedido foi interrompido. Normalmente basta repetir.";
            case "LV RESET":
                return "O adaptador reiniciou por tensão baixa (Low Voltage). A bateria de 12V pode estar fraca — carregue-a ou verifique-a.";
            case "DATA ERROR":
            case "FB ERROR":
                return "Erro de dados na linha. Má ligação ou interferência: reencaixe a ficha e tente outro adaptador se persistir.";
            case "?":
                return "O adaptador não percebeu o comando. Pode ser um clone incompatível ou firmware estranho.";
            case "ACT ALERT":
                return "O adaptador entrou em modo de poupança. Mexa/reative-o e tente de novo.";
            default:
                return "Erro do adaptador: " + err + ".";
        }
    }

    /** Conselho para um código de resposta negativa UDS. */
    public static String explainNrc(int nrc) {
        switch (nrc) {
            case 0x31: return "O módulo existe mas esse dado (DID) não — é normal ao descobrir parâmetros ou quando o DID não serve para esta versão do carro.";
            case 0x33:
            case 0x35:
            case 0x36: return "Função protegida por segurança (0x27). A app é só de leitura e não desbloqueia — é esperado e não há nada a mudar.";
            case 0x11:
            case 0x7F: return "Esse módulo não suporta o serviço pedido (ou é preciso mudar de sessão de diagnóstico primeiro).";
            case 0x12:
            case 0x7E: return "A subfunção não é suportada por este módulo.";
            case 0x22: return "O carro não está no estado certo para este pedido (ignição, carga, veículo parado…). Ponha-o na condição pedida e repita.";
            case 0x13: return "Formato/comprimento do pedido inválido — é um erro da app a corrigir. Exporte o registo e envie-mo.";
            case 0x24: return "Sequência de pedidos errada — provável questão de ordem interna; exporte o registo se se repetir.";
            case 0x78:
            case 0x21: return "Resposta pendente/ocupado — normal; a app repete sozinha.";
            default: return Nrc.text(nrc) + ".";
        }
    }

    /** Análise global da sessão. Devolve achados por ordem de importância. */
    public static List<Finding> diagnose(SessionLog log) {
        List<Finding> out = new ArrayList<>();
        if (log == null || log.countTx == 0) {
            out.add(new Finding(Level.INFO, "Ainda sem ligação",
                    "Não há tráfego registado nesta sessão. Ligue-se ao carro (Bluetooth ou DoIP) e faça uma leitura; depois volte aqui."));
            return out;
        }

        // Adaptador
        if (log.adapterId.isEmpty())
            out.add(new Finding(Level.WARN, "Adaptador não identificado",
                    "O adaptador não devolveu identificação (ATZ/STI). Pode ser um clone problemático ou a ligação Bluetooth caiu a meio."));

        // Tensão 12V
        if (!Double.isNaN(log.lastVoltage) && log.lastVoltage < 11.5)
            out.add(new Finding(Level.BAD, String.format(Locale.US, "Tensão 12V baixa (%.1f V)", log.lastVoltage),
                    "Abaixo de ~11,5 V a comunicação torna-se instável e os módulos podem não acordar. Carregue/verifique a bateria de 12V antes de confiar nos resultados."));

        // Erros do adaptador
        for (Map.Entry<String, Integer> e : log.elmErrors.entrySet()) {
            if (e.getKey().equals("NO DATA")) continue; // tratado em conjunto abaixo
            out.add(new Finding(Level.BAD, "Erro do adaptador: " + e.getKey() + " (×" + e.getValue() + ")", explainError(e.getKey())));
        }

        // Nada respondeu
        boolean nothingAnswered = log.countPos == 0 && (log.countNone > 0 || log.countNeg > 0 || !log.elmErrors.isEmpty());
        if (nothingAnswered)
            out.add(new Finding(Level.BAD, "Nenhum módulo respondeu com dados",
                    "Não houve uma única resposta positiva. O mais provável é o carro estar a dormir (abra uma porta / carregue no travão) ou o protocolo estar errado. Confirme a ligação e tente de novo."));

        // Respostas negativas por NRC
        for (Map.Entry<Integer, Integer> e : log.nrcs.entrySet()) {
            int nrc = e.getKey();
            Level lv = (nrc == 0x33 || nrc == 0x35 || nrc == 0x36 || nrc == 0x31 || nrc == 0x78 || nrc == 0x21) ? Level.INFO : Level.WARN;
            out.add(new Finding(lv, "Recusa 0x" + Hex.h2(nrc) + " — " + Nrc.text(nrc) + " (×" + e.getValue() + ")", explainNrc(nrc)));
        }

        // Muito NO DATA mas com algum sucesso = normal (módulos ausentes)
        Integer nd = log.elmErrors.get("NO DATA");
        if (nd != null && log.countPos > 0)
            out.add(new Finding(Level.INFO, "Alguns \"NO DATA\" (×" + nd + ")",
                    "Normal: são endereços sem módulo neste carro. Como houve respostas positivas, a ligação está boa."));

        // Veredicto: saudável se houve respostas positivas e nenhum problema grave
        boolean anyBad = false;
        for (Finding f : out) if (f.level == Level.BAD) anyBad = true;
        if (log.countPos > 0 && !nothingAnswered && !anyBad)
            out.add(0, new Finding(Level.OK, "Ligação saudável",
                    log.countPos + " resposta(s) positiva(s). A comunicação com o carro está a funcionar."));
        else if (out.isEmpty())
            out.add(new Finding(Level.OK, "Sem problemas registados",
                    "Não foram detetados erros nesta sessão."));

        return out;
    }
}
