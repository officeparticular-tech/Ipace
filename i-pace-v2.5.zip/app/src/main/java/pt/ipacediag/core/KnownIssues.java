package pt.ipacediag.core;

import java.util.ArrayList;
import java.util.List;

/**
 * Recalls e falhas conhecidas do Jaguar I-Pace.
 *
 * Distingue o que a JLR assumiu oficialmente (RECALL / boletim TSB-SSM) do que é
 * reportado pela comunidade. Os recalls aqui são as campanhas globais da JLR (números
 * "H…") com a referência NHTSA (EUA); em Portugal/UE, o dono deve confirmar pelo VIN
 * junto da JLR Portugal / IMT, porque a elegibilidade e as datas podem diferir.
 *
 * Factos resumidos por nós a partir de registos públicos (NHTSA/ODI e imprensa);
 * atualizado em 2026-11-25. Rever periodicamente — a lista evolui.
 */
public final class KnownIssues {
    private KnownIssues() {}

    public enum Kind { RECALL, TSB, COMMUNITY }

    public static final class Issue {
        public final Kind kind;
        public final String ref;      // nº de campanha JLR / código
        public final String title;
        public final String date;     // data de referência
        public final String models;   // anos abrangidos
        public final String desc;     // o que é
        public final String remedy;   // o que fazem/fazer
        public final String source;   // fonte (ex.: NHTSA 24V633)

        Issue(Kind kind, String ref, String title, String date, String models, String desc, String remedy, String source) {
            this.kind = kind; this.ref = ref; this.title = title; this.date = date;
            this.models = models; this.desc = desc; this.remedy = remedy; this.source = source;
        }
    }

    private static final List<Issue> LIST = new ArrayList<>();
    static {
        // --- RECALLS: saga do sobreaquecimento da bateria de alta tensão ---
        r("H572", "Bateria AT pode sobreaquecer — remédio mais recente", "2024 (aviso: estacionar no exterior)",
                "2020–2021 (e substitui campanhas anteriores)",
                "Risco de sobreaquecimento/incêndio da bateria de alta tensão. Substitui as campanhas 23V369, 23V709 e 24V085; a JLR aconselhou estacionar no exterior, longe de edifícios.",
                "Remédio novo obrigatório mesmo em carros já reparados nas campanhas anteriores. Confirmar elegibilidade pelo VIN.",
                "JLR H570/H571/H572; imprensa 2024");
        r("H514 / H536", "Substituição da bateria de alta tensão", "notificação 26-06-2024 (H514v7: 11-09-2025)",
                "2019 (fabricados em Graz 09-01-2018 a 14-03-2019)",
                "Reparação provisória anterior incorreta; mantém-se o risco de sobreaquecimento/incêndio.",
                "Substituição da bateria de alta tensão, sem custos. ~2760 viaturas nos EUA.",
                "NHTSA 24V633 (JLR H514)");
        r("H471", "Módulo BECM reparado incorretamente", "08-02-2024 (H471v3)",
                "2019–2024",
                "Reparação do BECM feita de forma incorreta mantém o risco de sobreaquecimento.",
                "Nova atualização/verificação do BECM, sem custos.",
                "NHTSA 24V085 (JLR H471)");
        r("H459", "Repetição da atualização de software do BECM", "18-10-2023",
                "sobretudo 2021 (carros já sob 23V369)",
                "A reparação anterior (23V369) pode não ter ficado bem concluída.",
                "Atualizar de novo o software do BECM, sem custos. ~501 viaturas.",
                "NHTSA 23V709 (JLR H459)");
        r("H441", "Atualização de software do BECM", "25-05-2023 (notificação 18-07-2023)",
                "2019–2024",
                "A bateria de alta tensão pode sobreaquecer. Primeira grande campanha de software do BECM.",
                "Atualização do software do BECM, sem custos. ~6422 viaturas.",
                "NHTSA 23V369 (JLR H441)");
        r("H468", "Fixadores do módulo da bateria aos barramentos", "08-02-2024",
                "2019–2020",
                "Os fixadores que seguram o módulo da bateria aos barramentos podem não estar bem apertados, causando arco elétrico.",
                "Inspeção/aperto, sem custos.",
                "NHTSA 24V086 (JLR H468)");
        r("AVAS", "Som de aviso a peões insuficiente", "2024",
                "2021–2022",
                "O veículo pode não emitir som de aviso suficiente parado e em marcha-atrás (sistema AVAS).",
                "Atualização de software, sem custos.",
                "NHTSA (recall AVAS I-Pace)");

        // --- TSB / boletins técnicos ---
        t("P0AA6-1A", "Falha de isolamento HVIL (BECM)", "boletim técnico",
                "2019–2024",
                "Código P0AA6 registado no BECM como falha de isolamento de alta tensão (HVIL). Pode surgir com humidade/água nos conectores de AT, sobretudo em carregamento rápido.",
                "Diagnóstico guiado JLR; confirmar se a atualização H441 do BECM foi aplicada; documentar dentro da garantia.");

        // --- Reportado pela comunidade (não oficial) ---
        c("12V", "Descarga/falha da bateria de 12V", "comunidade",
                "todos",
                "Falhas e descarga da bateria auxiliar de 12V são relato frequente; associadas a códigos como U3003. Podem causar falhas estranhas de arranque e de módulos.",
                "Testar as duas baterias de 12V; substituir se fraca. Após substituir, pode ser preciso reaprendizagem/registo.");
        c("InControl", "Falhas do InControl Touch Pro (infotainment)", "comunidade",
                "sobretudo pré-facelift",
                "Bloqueios, reinícios e lentidão do sistema de infotainment são relatos comuns na comunidade.",
                "Atualizações de software (OTA/oficina); reinício do sistema. Não acessível por OBD.");
    }

    private static void r(String ref, String title, String date, String models, String desc, String remedy, String source) {
        LIST.add(new Issue(Kind.RECALL, ref, title, date, models, desc, remedy, source));
    }
    private static void t(String ref, String title, String date, String models, String desc, String remedy) {
        LIST.add(new Issue(Kind.TSB, ref, title, date, models, desc, remedy, "JLR TOPIx (boletim)"));
    }
    private static void c(String ref, String title, String date, String models, String desc, String remedy) {
        LIST.add(new Issue(Kind.COMMUNITY, ref, title, date, models, desc, remedy, "comunidade I-Pace"));
    }

    public static List<Issue> all() { return LIST; }

    public static List<Issue> byKind(Kind k) {
        List<Issue> out = new ArrayList<>();
        for (Issue i : LIST) if (i.kind == k) out.add(i);
        return out;
    }

    public static int count() { return LIST.size(); }
}
