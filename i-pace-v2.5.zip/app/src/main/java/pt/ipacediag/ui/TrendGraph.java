package pt.ipacediag.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/**
 * Gráfico de linha simples para a tendência da saúde da bateria (SOH %) ao longo do
 * tempo. Recebe pares (tempo em ms, valor %) já ordenados por tempo. Desenha eixos
 * discretos, a linha e os pontos. Sem dependências externas.
 */
public final class TrendGraph extends View {

    private long[] t = new long[0];
    private double[] v = new double[0];

    private final Paint axis = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint lbl = new Paint(Paint.ANTI_ALIAS_FLAG);

    public TrendGraph(Context c) {
        super(c);
        axis.setColor(Theme.STROKE);
        axis.setStrokeWidth(Theme.dp(c, 1));
        grid.setColor(Theme.SURFACE_2);
        grid.setStrokeWidth(Theme.dp(c, 1));
        line.setColor(Theme.TEAL);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(Theme.dp(c, 2));
        dot.setColor(Theme.GOLD);
        lbl.setColor(Theme.MUTED);
        lbl.setTextSize(Theme.dp(c, 11));
        setMinimumHeight(Theme.dp(c, 180));
    }

    public void set(long[] times, double[] values) {
        this.t = times == null ? new long[0] : times;
        this.v = values == null ? new double[0] : values;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas cv) {
        int w = getWidth(), h = getHeight();
        int padL = Theme.dp(getContext(), 34), padR = Theme.dp(getContext(), 10);
        int padT = Theme.dp(getContext(), 12), padB = Theme.dp(getContext(), 22);
        float x0 = padL, x1 = w - padR, y0 = padT, y1 = h - padB;

        if (v.length == 0) {
            lbl.setTextSize(Theme.dp(getContext(), 13));
            cv.drawText("Sem leituras guardadas ainda.", x0, (y0 + y1) / 2f, lbl);
            return;
        }

        // escala Y: usa os valores, com margem; limita a [0..100]
        double mn = Double.MAX_VALUE, mx = -Double.MAX_VALUE;
        for (double d : v) { if (Double.isNaN(d)) continue; mn = Math.min(mn, d); mx = Math.max(mx, d); }
        if (mn == Double.MAX_VALUE) return;
        double pad = Math.max(1, (mx - mn) * 0.2);
        double lo = Math.max(0, Math.floor(mn - pad)), hi = Math.min(100, Math.ceil(mx + pad));
        if (hi - lo < 2) { hi = Math.min(100, lo + 2); }

        // linhas de grelha + rótulos Y (3 níveis)
        for (int k = 0; k <= 2; k++) {
            double val = lo + (hi - lo) * k / 2.0;
            float y = (float) (y1 - (val - lo) / (hi - lo) * (y1 - y0));
            cv.drawLine(x0, y, x1, y, grid);
            cv.drawText(String.format(java.util.Locale.US, "%.0f", val), Theme.dp(getContext(), 4), y + Theme.dp(getContext(), 4), lbl);
        }
        cv.drawLine(x0, y0, x0, y1, axis);
        cv.drawLine(x0, y1, x1, y1, axis);

        // escala X por tempo
        long tmin = t[0], tmax = t[t.length - 1];
        long span = Math.max(1, tmax - tmin);

        float px = -1, py = -1;
        for (int i = 0; i < v.length; i++) {
            if (Double.isNaN(v[i])) continue;
            float x = (v.length == 1) ? (x0 + x1) / 2f : (float) (x0 + (double) (t[i] - tmin) / span * (x1 - x0));
            float y = (float) (y1 - (v[i] - lo) / (hi - lo) * (y1 - y0));
            if (px >= 0) cv.drawLine(px, py, x, y, line);
            cv.drawCircle(x, y, Theme.dp(getContext(), 3), dot);
            px = x; py = y;
        }
    }
}
